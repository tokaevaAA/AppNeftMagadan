#include <algorithm>
#include <iostream>
#include <iterator>
#include <unordered_set>
#include <vector>

std::vector<int> GetColorsOne(const std::vector<std::vector<int>>& automata,
    const std::vector<int>& terminals) {
    std::vector<int> colors(automata.size());
    for (int terminal : terminals) {
        colors[terminal] = 1;
    }
    return colors;
}

std::vector<std::vector<int>> FillTable(const std::vector<int>& colors,
    const std::vector<std::vector<int>>& automata) {
    std::vector<std::vector<int>> table(automata.size(),
        std::vector<int>(automata[0].size() + 1));
    for (size_t i = 0; i < automata.size(); ++i) {
        table[i][table[0].size() - 1] = colors[i];
        for (size_t j = 0; j < table[0].size() - 1; ++j) {
            if (automata[i][j] == -1) {
                table[i][table[0].size() - 2 - j] = -1;
            } else {
                table[i][table[0].size() - 2 - j] = colors[automata[i][j]];
            }
        }
    }
    return table;
}

void DFS(int current_vertex, const std::vector<std::vector<int>>& automata,
    std::vector<bool>& used) {
    used[current_vertex] = true;
    for (auto vertex : automata[current_vertex]) {
        if (!used[vertex]) {
            DFS(vertex, automata, used);
        }
    }
}

std::vector<std::vector<int>> GetAutomata(std::vector<int>& terminals,
    std::istream& in = std::cin) {
    // automata[i][char] = -1 iff delta(i, char) not defined
    size_t statesNum, terminalsNum, alphabetSize;
    in >> statesNum >> terminalsNum >> alphabetSize;
    terminals.resize(terminalsNum);
    for (int& terminal : terminals) {
        in >> terminal;
    }
    std::vector<std::vector<int>> automata(statesNum, std::vector<int>(alphabetSize, -1));
    for (size_t i = 0; i < statesNum * alphabetSize; ++i) {
        size_t source, target;
        char character;
        in >> source >> character >> target;
        automata[source][static_cast<size_t>(character - 'a')] = target;
    }
    return automata;
}

bool CompareTwoClasses(const std::vector<int>& fst, const std::vector<int>& snd) {
    size_t pos = 0;
    while (pos < fst.size() && fst[fst.size() - 1 - pos] == snd[fst.size() - 1 - pos]) {
        ++pos;
    }
    return pos != fst.size() && fst[fst.size() - 1 - pos] < snd[fst.size() - 1 - pos];
}

std::vector<int> RadixSort(const std::vector<std::vector<int>>& table, int max_number) {
    if (table.size() == 1) {
        return {0};
    }
    std::vector<size_t> idxs(table.size());
    for (size_t i = 0; i < table.size(); ++i) {
        idxs[i] = i;
    }
    for (size_t col = 0; col < table[0].size(); ++col) {
        std::vector<std::vector<size_t>> indexes(max_number);
        for (size_t i = 0; i < table.size(); ++i) {
            indexes[table[idxs[i]][col]].push_back(idxs[i]);
        }
        size_t curr_idx = 0;
        for (auto& index : indexes) {
            for (auto idx : index) {
                idxs[curr_idx++] = idx;
            }
        }
    }
    std::vector<int> colors(table.size());
    int current_color = 0;
    for (size_t i = 0; i < table.size() - 1; ++i) {
        colors[idxs[i]] = current_color;
        if (CompareTwoClasses(table[idxs[i]], table[idxs[i + 1]])) {
            ++current_color;
        }
    }
    colors[idxs[table.size() - 1]] = current_color;
    return colors;
}

size_t NumberOfClasses(const std::vector<std::vector<int>>& automata,
    const std::vector<int>& terminals) {
    auto colors = GetColorsOne(automata, terminals);
    int max_number = 2;
    bool isGoing = true;
    while (isGoing) {
        auto colors_new = RadixSort(FillTable(colors, automata), max_number);
        if (colors == colors_new) {
            isGoing = false;
        }
        colors = colors_new;
        max_number = *std::max_element(colors.begin(), colors.end()) + 1;
    }
    std::unordered_set<int> classes;
    std::vector<bool> used(automata.size(), false);
    DFS(0, automata, used);
    for (size_t i = 0; i < automata.size(); ++i) {
        if (used[i]) {
            classes.insert(colors[i]);
        }
    }
    return classes.size();
}

int main() {
    std::ios_base::sync_with_stdio(false);
    std::vector<int> terminals;
    auto automata = GetAutomata(terminals);
    std::cout << NumberOfClasses(automata, terminals) << std::endl;
    return 0;
}
