#include <algorithm>
#include <iostream>
#include <vector>

std::vector<std::vector<int>> GetAutomata(std::vector<bool>& terminals,
    std::istream& in = std::cin) {
    int statesNum, alphabetNum, terminalsNum;
    in >> statesNum >> terminalsNum >> alphabetNum;
    terminals.resize(statesNum, false);
    for (size_t i = 0; i < static_cast<size_t>(terminalsNum); ++i) {
        size_t terminal;
        in >> terminal;
        terminals[terminal] = true;
    }
    std::vector<std::vector<int>> automata(statesNum, std::vector<int>(alphabetNum));
    for (size_t i = 0; i < static_cast<size_t>(statesNum * alphabetNum); ++i) {
        int source, target;
        char character;
        in >> source >> character >> target;
        automata[source][static_cast<size_t>(character - 'a')] = target;
    }
    return automata;
}

bool DFS(const std::vector<std::vector<int>>& automataFirst,
    const std::vector<bool>& terminalsFirst, const std::vector<std::vector<int>>& automataSecond,
    const std::vector<bool>& terminalsSecond, int stateFirst, int stateSecond,
    std::vector<std::vector<bool>>& used) {
    if (terminalsFirst[stateFirst] ^ terminalsSecond[stateSecond]) {
        return false;
    }
    used[stateFirst][stateSecond] = true;
    for (size_t i = 0; i < automataFirst[0].size(); ++i) {
        int nextStateFirst = automataFirst[stateFirst][i];
        int nextStateSecond = automataSecond[stateSecond][i];
        if (!used[nextStateFirst][nextStateSecond] && !DFS(automataFirst, terminalsFirst,
        automataSecond, terminalsSecond, nextStateFirst, nextStateSecond, used)) {
            return false;
        }
    }
    return true;
}

bool CheckEquivalency(const std::vector<std::vector<int>>& automataFirst,
    const std::vector<bool>& terminalsFirst, const std::vector<std::vector<int>>& automataSecond,
    const std::vector<bool>& terminalsSecond) {
    std::vector<std::vector<bool>> used(automataFirst.size(),
        std::vector<bool>(automataSecond.size(), false));
    return DFS(automataFirst, terminalsFirst, automataSecond, terminalsSecond, 0, 0, used);
}

int main() {
    std::ios_base::sync_with_stdio(false);
    std::vector<bool> terminalsFirst, terminalsSecond;
    auto automataFirst = GetAutomata(terminalsFirst);
    auto automataSecond = GetAutomata(terminalsSecond);
    if (CheckEquivalency(automataFirst, terminalsFirst, automataSecond, terminalsSecond)) {
        std::cout << "EQUIVALENT" << "\n";
    } else {
        std::cout << "NOT EQUIVALENT" << "\n";
    }
    return 0;
}
