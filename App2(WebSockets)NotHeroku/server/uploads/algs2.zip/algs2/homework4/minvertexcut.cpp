#include <algorithm>
#include <iostream>
#include <queue>
#include <utility>
#include <vector>
#include <set>

std::vector<std::pair<int, int>> ReadCoordinates(size_t size, std::istream& in = std::cin) {
    std::vector<std::pair<int, int>> coordinates(size);
    for (auto& point : coordinates) {
        in >> point.first >> point.second;
    }
    return coordinates;
}

struct Edge {
    int src;
    int dest;
    int cap;
    int flow;
};

class Graph {
public:
    explicit Graph(int rows, int cols, std::pair<int, int> source, std::pair<int, int> sink) {
        adj_lists_.resize(2 * rows * cols);
        source_ = (source.second - 1) * cols + source.first - 1;
        sink_ = (sink.second - 1) * cols + sink.first - 1;
    }

    void AddEdge(int src, int dest, int capacity) {
        adj_lists_[src].push_back(edges_.size());
        edges_.push_back({src, dest, capacity, 0});
        adj_lists_[dest].push_back(edges_.size());
        edges_.push_back({dest, src, 0, 0});
    }

    std::vector<int> BFS() {
        std::vector<int> dist(adj_lists_.size(), -1);
        std::queue<int> order({source_});
        dist[source_] = 0;
        while (!order.empty()) {
            int curr_vertex = order.front();
            order.pop();
            for (int id : adj_lists_[curr_vertex]) {
                if (dist[edges_[id].dest] == -1 && edges_[id].cap - edges_[id].flow > 0) {
                    dist[edges_[id].dest] = dist[curr_vertex] + 1;
                    order.push(edges_[id].dest);
                }
            }
        }
        return dist;
    }

    void FindCut(std::set<int>& cut, int start, std::vector<bool>& used,
        const std::vector<int>& types) {
        used[start] = true;
        for (int id : adj_lists_[start]) {
            if (!used[edges_[id].dest] && edges_[id].cap - edges_[id].flow > 0) {
                FindCut(cut, edges_[id].dest, used, types);
            }
        }
        cut.insert(start);
    }

    bool IsPathFromSourceToSink(int start, std::vector<bool>& used,
        const std::vector<int>& types) {
        if (start == sink_) {
            return true;
        }
        used[start] = true;
        for (int id : adj_lists_[start]) {
            if (!used[edges_[id].dest] && types[edges_[id].dest] == 0
            && edges_[id].cap > 0
            && IsPathFromSourceToSink(edges_[id].dest, used, types)) {
                return true;
            }
        }
        return false;
    }

    int DFS(std::vector<int>& pointers, const std::vector<int>& dist,
        int start, int flow) {
        if (flow == 0) {
            return 0;
        }
        if (start == sink_) {
            return flow;
        }
        while (static_cast<size_t>(pointers[start]) < adj_lists_[start].size()) {
            int id = adj_lists_[start][pointers[start]];
            int target = edges_[id].dest;
            if (dist[target] != dist[start] + 1) {
                ++pointers[start];
                continue;
            }
            int pushed = DFS(pointers, dist, target,
                std::min(edges_[id].cap - edges_[id].flow, flow));
            if (pushed > 0) {
                edges_[id].flow += pushed;
                edges_[id ^ 1].flow -= pushed;
                return pushed;
            }
            ++pointers[start];
        }
        return 0;
    }

    int Dinic() {
        for (auto& edge : edges_) {
            edge.flow = 0;
        }
        int answer = 0;
        std::vector<int> pointers(adj_lists_.size());
        bool enough = false;
        while (!enough) {
            pointers.assign(adj_lists_.size(), 0);
            auto dist = BFS();
            if (dist[sink_] == -1) {
                enough = true;
                return answer;
            }
            while (int pushed = DFS(pointers, dist, source_, inf_)) {
                answer += pushed;
            }
        }
        return answer;
    }

    int GetSource() {
        return source_;
    }

private:
    std::vector<Edge> edges_;
    std::vector<std::vector<int>> adj_lists_;
    int source_, sink_;
    const int inf_ = 100000000;
};

bool IsAvailable(int row, int col, int rows, int cols) {
    return 0 <= row && 0 <= col && row < rows && col < cols;
}

void CreateLocalEdgesNoWall(Graph& graph, int row, int col, int rows, int cols,
    const std::vector<int>& types) {
    const int inf = 100000000;
    if (IsAvailable(row - 1, col, rows, cols) && types[(row - 1) * cols + col] != 2) {
        graph.AddEdge(row * cols + col, (row - 1) * cols + col, inf);
    }
    if (IsAvailable(row + 1, col, rows, cols) && types[(row + 1) * cols + col] != 2) {
        graph.AddEdge(row * cols + col, (row + 1) * cols + col, inf);
    }
    if (IsAvailable(row, col - 1, rows, cols) && types[row * cols + col - 1] != 2) {
        graph.AddEdge(row * cols + col, row * cols + col - 1, inf);
    }
    if (IsAvailable(row, col + 1, rows, cols) && types[row * cols + col + 1] != 2) {
        graph.AddEdge(row * cols + col, row * cols + col + 1, inf);
    }
}

void CreateLocalEdgesPosWall(Graph& graph, int row, int col, int rows, int cols,
    const std::vector<int>& types) {
    const int inf = 100000000;
    graph.AddEdge(row * cols + col, row * cols + col + rows * cols, 1);
    if (IsAvailable(row - 1, col, rows, cols) && types[(row - 1) * cols + col] != 2) {
        graph.AddEdge(row * cols + col + rows * cols, (row - 1) * cols + col, inf);
    }
    if (IsAvailable(row + 1, col, rows, cols) && types[(row + 1) * cols + col] != 2) {
        graph.AddEdge(row * cols + col + rows * cols, (row + 1) * cols + col, inf);
    }
    if (IsAvailable(row, col - 1, rows, cols) && types[row * cols + col - 1] != 2) {
        graph.AddEdge(row * cols + col + rows * cols, row * cols + col - 1, inf);
    }
    if (IsAvailable(row, col + 1, rows, cols) && types[row * cols + col + 1] != 2) {
        graph.AddEdge(row * cols + col + rows * cols, row * cols + col + 1, inf);
    }
}

Graph CreateGraph(int rows, int cols, std::pair<int, int> source,
    std::pair<int, int> sink, const std::vector<int>& vertex_types) {
    // m - cols, n - rows
    // [i][j] --> i * m + j, i = 0 ... n - 1, j = 0 ... m - 1
    // 0 - no wall, 1 - possible wall, 2 - mountain
    Graph graph(rows, cols, source, sink);
    for (int row = 0; row < rows; ++row) {
        for (int col = 0; col < cols; ++col) {
            if (vertex_types[row * cols + col] == 0) {
                CreateLocalEdgesNoWall(graph, row, col, rows, cols, vertex_types);
            } else if (vertex_types[row * cols + col] == 1) {
                CreateLocalEdgesPosWall(graph, row, col, rows, cols, vertex_types);
            }
        }
    }
    return graph;
}

std::pair<int, int> Inverse(int vertex, int cols) {
    int second = 0;
    while (vertex >= 0) {
        vertex -= cols;
        ++second;
    }
    return {vertex + cols, second - 1};
}

std::vector<std::pair<int, int>> Solve(int rows, int cols, std::pair<int, int> source,
    std::pair<int, int> sink, const std::vector<std::pair<int, int>>& possible_walls,
    const std::vector<std::pair<int, int>>& mountains, bool& can) {
    std::vector<int> vertex_types(2 * rows * cols);
    for (const auto& point : possible_walls) {
        vertex_types[(point.second - 1) * cols + point.first - 1] = 1;
    }
    for (const auto& point : mountains) {
        vertex_types[(point.second - 1) * cols + point.first - 1] = 2;
    }
    Graph graph = CreateGraph(rows, cols, source, sink, vertex_types);
    std::set<int> cut;
    std::vector<bool> used(2 * rows * cols, false);
    if (graph.IsPathFromSourceToSink(graph.GetSource(), used, vertex_types)) {
        // -1
        can = false;
        return {};
    }
    used.assign(2 * rows * cols, false);
    graph.Dinic();
    graph.FindCut(cut, graph.GetSource(), used, vertex_types);
    std::vector<std::pair<int, int>> answer;
    for (int vertex : cut) {
        if (vertex < rows * cols && vertex_types[vertex] == 1
        && cut.find(vertex + cols * rows) == cut.end()) {
            answer.push_back(Inverse(vertex, cols));
        }
    }
    return answer;
}

void PrintPairs(const std::vector<std::pair<int, int>>& data, std::ostream& out = std::cout) {
    out << data.size() << "\n";
    for (const auto& elem : data) {
        out << elem.first + 1 << " " << elem.second + 1 << "\n";
    }
}

int main() {
    std::ios_base::sync_with_stdio(false);
    int cols, rows;
    std::cin >> cols >> rows;
    size_t pos_wals_size, mount_size;
    std::cin >> mount_size >> pos_wals_size;
    auto mountains = ReadCoordinates(mount_size);
    auto possible_walls = ReadCoordinates(pos_wals_size);
    std::pair<int, int> source, sink;
    std::cin >> source.first >> source.second;
    std::cin >> sink.first >> sink.second;
    bool can = true;
    auto cut = Solve(rows, cols, source, sink, possible_walls, mountains, can);
    if (!can) {
        std::cout << -1 << "\n";
    } else {
        PrintPairs(cut);
    }
    return 0;
}
