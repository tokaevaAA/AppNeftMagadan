#include <algorithm>
#include <iostream>
#include <queue>
#include <vector>

std::vector<int> ReadVector(size_t size, std::istream& in = std::cin) {
    std::vector<int> result(size);
    for (int& elem : result) {
        in >> elem;
    }
    return result;
}

std::vector<std::vector<int>> ReadMatrix(size_t size, std::istream& in = std::cin) {
    std::vector<std::vector<int>> result(size, std::vector<int>(size));
    for (auto& row : result) {
        for (int& elem : row) {
            in >> elem;
        }
    }
    return result;
}

struct Edge {
    int src;
    int dest;
    int cap;
    int flow;
};

class Graph {
public:
    explicit Graph(int verticesNum) {
        adjLists_.resize(verticesNum * verticesNum + verticesNum + 2);
        source_ = verticesNum - 1;
        sink_ = verticesNum;
    }

    void AddEdge(int src, int dest, int capacity) {
        adjLists_[src].push_back(edges_.size());
        edges_.push_back({src, dest, capacity, 0});
        adjLists_[dest].push_back(edges_.size());
        edges_.push_back({dest, src, 0, 0});
    }

    std::vector<int> BFS() {
        std::vector<int> dist(adjLists_.size(), -1);
        std::queue<int> order({source_});
        dist[source_] = 0;
        while (!order.empty()) {
            int currVertex = order.front();
            order.pop();
            for (int id : adjLists_[currVertex]) {
                if (dist[edges_[id].dest] == -1 && edges_[id].cap - edges_[id].flow > 0) {
                    dist[edges_[id].dest] = dist[currVertex] + 1;
                    order.push(edges_[id].dest);
                }
            }
        }
        return dist;
    }

    int DFS(std::vector<int>& pointers, const std::vector<int>& dist,
        int start, int flow) {
        if (flow == 0) {
            return 0;
        }
        if (start == sink_) {
            return flow;
        }
        while (static_cast<size_t>(pointers[start]) < adjLists_[start].size()) {
            int id = adjLists_[start][pointers[start]];
            int target = edges_[id].dest;
            if (dist[target] != dist[start] + 1) {
                ++pointers[start];
                continue;
            }
            int pushed = DFS(pointers, dist, target,
                std::min(edges_[id].cap - edges_[id].flow, flow));
            if (pushed) {
                edges_[id].flow += pushed;
                edges_[id ^ 1].flow -= pushed;
                return pushed;
            }
            ++pointers[start];
        }
        return 0;
    }

    int Dinic() {
        int answer = 0;
        std::vector<int> pointers(adjLists_.size());
        bool enough = false;
        while (!enough) {
            pointers.assign(adjLists_.size(), 0);
            auto dist = BFS();
            if (dist[sink_] == -1) {
                enough = true;
                return answer;
            }
            while (int pushed = DFS(pointers, dist, source_, INF_)) {
                answer += pushed;
            }
        }
        return answer;
    }

private:
    std::vector<Edge> edges_;
    std::vector<std::vector<int>> adjLists_;
    int source_, sink_;
    const int INF_ = 100000000;
};

bool Solve(const std::vector<int>& wins, const std::vector<int>& rgames,
    const std::vector<std::vector<int>>& games) {
    int teamsNum = static_cast<int>(wins.size());
    Graph graph(teamsNum);
    for (int i = 0; i < teamsNum - 1; ++i) {
        if (wins[0] + rgames[0] - wins[i + 1] < 0) {
            return false;
        }
        graph.AddEdge(i, teamsNum, wins[0] + rgames[0] - wins[i + 1]);
    }
    int currNumber = teamsNum + 1, gamesToPlay = 0;
    for (int i = 1; i < teamsNum; ++i) {
        for (int j = 1; j < i; ++j) {
            if (games[i][j]) {
                graph.AddEdge(teamsNum - 1, currNumber, games[i][j]);
                graph.AddEdge(currNumber, i - 1, games[i][j]);
                graph.AddEdge(currNumber, j - 1, games[i][j]);
                ++currNumber;
                gamesToPlay += games[i][j];
            }
        }
    }
    return graph.Dinic() == gamesToPlay;
}

int main() {
    std::ios_base::sync_with_stdio(false);
    size_t size;
    std::cin >> size;
    auto wins = ReadVector(size);
    auto rgames = ReadVector(size);
    auto games = ReadMatrix(size);
    if (Solve(wins, rgames, games)) {
        std::cout << "YES" << "\n";
    } else {
        std::cout << "NO" << "\n";
    }
    return 0;
}
