#include <algorithm>
#include <iostream>
#include <vector>
#include <utility>
#include <queue>

std::vector<int> ReadArray(size_t size, std::istream& in = std::cin) {
    std::vector<int> result(size);
    for (int& elem : result) {
        in >> elem;
    }
    return result;
}

std::vector<std::pair<int, int>> ReadEdges(size_t edges_num, std::istream& in = std::cin) {
    std::vector<std::pair<int, int>> result(edges_num);
    for (auto& edge : result) {
        in >> edge.first >> edge.second;
    }
    return result;
}

struct Edge {
    int src;
    int dest;
    int cap;
    int flow;
};

class Graph {
public:
    explicit Graph(int vertices_num) {
        adj_lists_.resize(vertices_num + 2);
        source_ = 0;
        sink_ = vertices_num + 1;
    }

    void AddEdge(int src, int dest, int capacity) {
        adj_lists_[src].push_back(edges_.size());
        edges_.push_back({src, dest, capacity, 0});
        adj_lists_[dest].push_back(edges_.size());
        edges_.push_back({dest, src, 0, 0});
    }

    void ChangeCapacity(int edge_num, int new_capacity) {
        edges_[edge_num].cap = new_capacity;
    }

    std::vector<int> BFS() {
        std::vector<int> dist(adj_lists_.size(), -1);
        std::queue<int> order({source_});
        dist[source_] = 0;
        while (!order.empty()) {
            int curr_vertex = order.front();
            order.pop();
            for (int id : adj_lists_[curr_vertex]) {
                if (dist[edges_[id].dest] == -1 && edges_[id].cap - edges_[id].flow > 0) {
                    dist[edges_[id].dest] = dist[curr_vertex] + 1;
                    order.push(edges_[id].dest);
                }
            }
        }
        return dist;
    }

    int DFS(std::vector<int>& pointers, const std::vector<int>& dist,
        int start, int flow) {
        if (flow == 0) {
            return 0;
        }
        if (start == sink_) {
            return flow;
        }
        while (static_cast<size_t>(pointers[start]) < adj_lists_[start].size()) {
            int id = adj_lists_[start][pointers[start]];
            int target = edges_[id].dest;
            if (dist[target] != dist[start] + 1) {
                ++pointers[start];
                continue;
            }
            int pushed = DFS(pointers, dist, target,
                std::min(edges_[id].cap - edges_[id].flow, flow));
            if (pushed > 0) {
                edges_[id].flow += pushed;
                edges_[id ^ 1].flow -= pushed;
                return pushed;
            }
            ++pointers[start];
        }
        return 0;
    }

    int Dinic() {
        for (auto& edge : edges_) {
            edge.flow = 0;
        }
        int answer = 0;
        std::vector<int> pointers(adj_lists_.size());
        bool enough = false;
        while (!enough) {
            pointers.assign(adj_lists_.size(), 0);
            auto dist = BFS();
            if (dist[sink_] == -1) {
                enough = true;
                return answer;
            }
            while (int pushed = DFS(pointers, dist, source_, inf_)) {
                answer += pushed;
            }
        }
        return answer;
    }

private:
    std::vector<Edge> edges_;
    std::vector<std::vector<int>> adj_lists_;
    int source_, sink_;
    const int inf_ = 100000000;
};

template<class Predicate>
int BinSearch(int begin, int end, Predicate predicate) {
    int left = begin, right = end;
    while (right > left) {
        int middle = left + (right - left) / 2;
        if (predicate(middle)) {
            right = middle;
        } else {
            left = middle + 1;
        }
    }
    return left;
}

bool CheckForValue(Graph& graph, int current_value, int people_num, int wanted_value) {
    for (int id = 2 * people_num; id < 4 * people_num; id += 2) {
        graph.ChangeCapacity(id, current_value);
    }
    return graph.Dinic() == wanted_value;
}

int Solve(const std::vector<int>& wealths, const std::vector<std::pair<int, int>>& edges) {
    int people_num = static_cast<int>(wealths.size());
    const int inf = 100000001;
    Graph graph(people_num);
    for (int i = 0; i < people_num; ++i) {
        graph.AddEdge(0, i + 1, wealths[i]);
    }
    for (int i = 0; i < people_num; ++i) {
        graph.AddEdge(i + 1, people_num + 1, inf);
    }
    for (const auto& edge : edges) {
        graph.AddEdge(edge.first, edge.second, inf);
    }
    int total_wealth = 0;
    for (const int& wealth : wealths) {
        total_wealth += wealth;
    }
    return BinSearch(0, inf, [&](int current_value) {
        return CheckForValue(graph, current_value, people_num, total_wealth);
    });
}

int main() {
    std::ios_base::sync_with_stdio(false);
    size_t people_num, edges_num;
    std::cin >> people_num >> edges_num;
    auto wealths = ReadArray(people_num);
    auto edges = ReadEdges(edges_num);
    std::cout << Solve(wealths, edges) << "\n";
    return 0;
}
