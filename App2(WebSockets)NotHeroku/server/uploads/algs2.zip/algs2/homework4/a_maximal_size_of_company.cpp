#include <algorithm>
#include <iostream>
#include <numeric>
#include <vector>

using std::cin;
using std::cout;
using std::min;
using std::reverse;
using std::vector;

struct Game {
    Game(size_t first, size_t second, int result)
        : first(first),
          second(second),
          result(result) {}
    bool IsDraw() const {
        return result == 3;
    }
    size_t Winner() const {
        if (result == 1) {
            return first;
        }
        return second;
    }
    size_t Loser() const {
        if (result == 1) {
            return second;
        }
        return first;
    }
    size_t first;
    size_t second;
    int result;
};

class Partition {
public:
    Partition(vector<vector<size_t>>& groups,
              vector<size_t>& elements_group_id);
    size_t GroupsNumber() const;
    size_t GroupId(size_t element) const;
    const vector<size_t>& ElementsFromGroup(size_t group_id) const;
private:
    vector<vector<size_t>> groups_;
    vector<size_t> elements_group_id_;
};

Partition::Partition(vector<vector<size_t>>& groups,
                     vector<size_t>& elements_group_id) {
    this->groups_.swap(groups);
    this->elements_group_id_.swap(elements_group_id);
}

size_t Partition::GroupsNumber() const {
    return groups_.size();
}

size_t Partition::GroupId(size_t element) const {
    return elements_group_id_[element];
}

const vector<size_t>& Partition::ElementsFromGroup(size_t group_id) const {
    return groups_[group_id];
}

class PartitionBuilder {
public:
    size_t CreateNewGroup();
    void AddElementToGroup(size_t group_id, size_t element);
    Partition Build();
private:
    size_t total_size_ = 0;
    vector<vector<size_t>> groups_;
};

size_t PartitionBuilder::CreateNewGroup() {
    groups_.emplace_back();
    return groups_.size() - 1;
}

void PartitionBuilder::AddElementToGroup(size_t group_id, size_t element) {
    ++total_size_;
    groups_[group_id].push_back(element);
}

Partition PartitionBuilder::Build() {
    vector<size_t> elements_group_id(total_size_);
    size_t group_id = 0;
    for (const auto& group: groups_) {
        for (auto elem: group) {
            elements_group_id[elem] = group_id;
        }
        ++group_id;
    }

    return Partition(groups_, elements_group_id);
}

class Graph {
public:
    explicit Graph(size_t size);
    const vector<size_t>& GetNeighbours(size_t vertex) const;
    void AddEdge(size_t from, size_t to);
    size_t Size() const;
private:
    vector<vector<size_t>> adjacency_list_;
};

Graph::Graph(size_t size) {
    adjacency_list_.assign(size, vector<size_t>());
}

const vector<size_t>& Graph::GetNeighbours(size_t vertex) const {
    return adjacency_list_[vertex];
}

void Graph::AddEdge(size_t from, size_t to) {
    adjacency_list_[from].push_back(to);
}

size_t Graph::Size() const {
    return adjacency_list_.size();
}

void InitializeGraphWithGames(Graph* graph, const vector<Game>& games) {
    for (const auto& game: games) {
        if (!game.IsDraw()) {
            graph->AddEdge(game.Winner(), game.Loser());
        }
    }
}

Graph TransposeGraph(const Graph& graph) {
    Graph tr_graph(graph.Size());
    for (size_t vertex = 0; vertex < graph.Size(); ++vertex) {
        for (auto to: graph.GetNeighbours(vertex)) {
            tr_graph.AddEdge(to, vertex);
        }
    }

    return tr_graph;
}

Graph BuildCondensation(const Graph& graph,
                        const Partition& strongly_connected_components) {
    auto size = strongly_connected_components.GroupsNumber();
    Graph condensation(size);

    for (size_t component_id = 0; component_id < size; ++component_id) {
        for (auto vertex: strongly_connected_components.ElementsFromGroup(component_id)) {
            for (auto to: graph.GetNeighbours(vertex)) {
                if (strongly_connected_components.GroupId(to) != component_id) {
                    condensation.AddEdge(component_id,
                                         strongly_connected_components.GroupId(to));
                }
            }
        }
    }

    return condensation;
}

class Visitor {
public:
    explicit Visitor(size_t size);
    void InitializeVertex(size_t vertex);
    void DiscoverVertex(size_t vertex);
    void ExamineEdge(size_t to, const Graph& graph);
    void FinishVertex(size_t vertex);
    void StartVertex(size_t vertex, const Graph& graph);
    bool IsVisited(size_t vertex) const;
    void Update() {}
private:
    vector<bool> used_;
};

Visitor::Visitor(size_t size) {
    used_.resize(size);
}

void Visitor::InitializeVertex(size_t vertex) {
    used_[vertex] = false;
}

void Visitor::DiscoverVertex(size_t vertex) {
    used_[vertex] = true;
}

bool Visitor::IsVisited(size_t vertex) const {
    return used_[vertex];
}

class OrderVisitor : public Visitor {
public:
    OrderVisitor(size_t size, vector<size_t>& order);
    void ExamineEdge(size_t to, const Graph& graph);
    void FinishVertex(size_t vertex);
    void StartVertex(size_t vertex, const Graph& graph);
private:
    vector<size_t>& order_;
};

OrderVisitor::OrderVisitor(size_t size, vector<size_t>& order)
    : Visitor(size), order_(order) {}

void OrderVisitor::ExamineEdge(size_t to, const Graph& graph) {
    if (!IsVisited(to)) {
        StartVertex(to, graph);
    }
}

void OrderVisitor::FinishVertex(size_t vertex) {
    order_.push_back(vertex);
}

void OrderVisitor::StartVertex(size_t vertex, const Graph &graph) {
    DiscoverVertex(vertex);
    for (auto to: graph.GetNeighbours(vertex)) {
        ExamineEdge(to, graph);
    }
    FinishVertex(vertex);
}

class PartitionVisitor : public Visitor {
public:
    PartitionVisitor(size_t size, PartitionBuilder& builder);
    void ExamineEdge(size_t to, const Graph& graph);
    void FinishVertex(size_t vertex);
    void StartVertex(size_t vertex, const Graph& graph);
    void Update();
private:
    PartitionBuilder& builder_;
    size_t current_group_id_;
};

PartitionVisitor::PartitionVisitor(size_t size, PartitionBuilder& builder)
    : Visitor(size), builder_(builder) {}

void PartitionVisitor::ExamineEdge(size_t to, const Graph& graph) {
    if (!IsVisited(to)) {
        StartVertex(to, graph);
    }
}

void PartitionVisitor::FinishVertex(size_t vertex) {
    builder_.AddElementToGroup(current_group_id_, vertex);
}

void PartitionVisitor::StartVertex(size_t vertex, const Graph &graph) {
    DiscoverVertex(vertex);
    for (auto to: graph.GetNeighbours(vertex)) {
        ExamineEdge(to, graph);
    }
    FinishVertex(vertex);
}

void PartitionVisitor::Update() {
    current_group_id_ = builder_.CreateNewGroup();
}

void TraverseGraphInDfsOrder(const Graph& graph, OrderVisitor visitor) {
    for (size_t vertex = 0; vertex < graph.Size(); ++vertex) {
        visitor.InitializeVertex(vertex);
    }

    for (size_t vertex = 0; vertex < graph.Size(); ++vertex) {
        if (!visitor.IsVisited(vertex)) {
            visitor.StartVertex(vertex, graph);
        }
    }
}

void TraverseGraphInDfsOrder(const Graph& graph,
                             const vector<size_t>& vertices_order,
                             PartitionVisitor visitor) {
    for (size_t vertex = 0; vertex < graph.Size(); ++vertex) {
        visitor.InitializeVertex(vertex);
    }

    for (auto vertex: vertices_order) {
        if (!visitor.IsVisited(vertex)) {
            visitor.Update();
            visitor.StartVertex(vertex, graph);
        }
    }
}

size_t CountMaximalSizeOfCompany(size_t people_num, vector<Game>& games) {
    Graph games_graph(people_num);
    InitializeGraphWithGames(&games_graph, games);

    vector<size_t> vertices_order;
    vertices_order.reserve(people_num);
    OrderVisitor order_visitor(people_num, vertices_order);
    TraverseGraphInDfsOrder(games_graph, order_visitor);
    reverse(vertices_order.begin(), vertices_order.end());

    Graph transposed_games_graph = TransposeGraph(games_graph);
    PartitionBuilder partition_builder;
    PartitionVisitor partition_visitor(people_num, partition_builder);
    TraverseGraphInDfsOrder(transposed_games_graph, vertices_order,
                            partition_visitor);

    Partition strongly_connected_components = partition_builder.Build();
    Graph transpose_condensation = TransposeGraph(
                BuildCondensation(games_graph, strongly_connected_components));

    size_t min_cardinality = people_num + 1;
    for (size_t component = 0; component < transpose_condensation.Size();
         ++component) {
        if (transpose_condensation.GetNeighbours(component).empty()) {
            min_cardinality = min(
                        min_cardinality,
                        strongly_connected_components.ElementsFromGroup(
                            component).size());
        }
    }

    return people_num + 1 - min_cardinality;
}

size_t ReadNumber(std::istream& in_stream = cin) {
    size_t number;
    in_stream >> number;
    return number;
}

vector<Game> ReadGames(std::istream& in_stream = cin) {
    size_t games_num;
    in_stream >> games_num;

    vector<Game> games;
    games.reserve(games_num);
    size_t first_player, second_player;
    int result;
    for (size_t i = 0; i < games_num; ++i) {
        in_stream >> first_player;
        in_stream >> second_player;
        in_stream >> result;
        games.emplace_back(first_player - 1, second_player - 1, result);
    }

    return games;
}

void PrintNumber(size_t number, std::ostream& out_stream = cout) {
    out_stream << number << "\n";
}

int main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(nullptr);

    auto people_num = ReadNumber();
    vector<Game> games = ReadGames();

    auto ans = CountMaximalSizeOfCompany(people_num, games);
    PrintNumber(ans);

    return 0;
}
