#include <algorithm>
#include <iostream>
#include <vector>
#include <complex>
#include <cmath>
#include <iterator>
#include <string>

int InvertBits(int number, int length) {
    int answer = 0, currCompare = 1;
    for (int i = 0; i < length; ++i, currCompare <<= 1) {
        answer |= ((number & currCompare) >> i) << (length - 1 - i);
    }
    return answer;
}

void ReverseArray(std::vector<std::complex<double>>& data) {
    int length = 0;
    while ((1 << length) < static_cast<int>(data.size())) {
        ++length;
    }
    for (int i = 0; i < static_cast<int>(data.size()); ++i) {
        int potencialReplace = InvertBits(i, length);
        if (i < potencialReplace) {
            std::swap(data[i], data[potencialReplace]);
        }
    }
}

void Step(std::vector<std::complex<double>>& data, size_t length, bool invert) {
    std::vector<std::complex<double>> roots(length >> 1);
    if (invert) {
        for (size_t i = 0; i < (length >> 1); ++i) {
            roots[i] = {cos(2 * M_PI * i / length), sin(-2 * M_PI * i / length)};
        }
    } else {
        for (size_t i = 0; i < (length >> 1); ++i) {
            roots[i] = {cos(2 * M_PI * i / length), sin(2 * M_PI * i / length)};
        }
    }
    for (size_t pos = 0; pos < data.size(); pos += length) {
        for (size_t i = 0; i < (length >> 1); ++i) {
            auto fst = data[pos + i], snd = roots[i] * data[pos + i + (length >> 1)];
            data[pos + i] = fst + snd;
            data[pos + i + (length >> 1)] = fst - snd;
        }
    }
}

void FFT(std::vector<std::complex<double>>& data, bool invert) {
    ReverseArray(data);
    for (size_t length = 2; length <= data.size(); length <<= 1) {
        Step(data, length, invert);
    }
    if (invert) {
        std::for_each(data.begin(), data.end(), [&data](auto& elem) {
            elem /= data.size();
        });
    }
}

void Multiply(const std::vector<int>& first, const std::vector<int>& second,
    std::vector<int>& res) {
    std::vector<std::complex<double>> fst(first.begin(), first.end()),
        snd(second.begin(), second.end());
    FFT(fst, false);
    FFT(snd, false);
    for (size_t i = 0; i < fst.size(); ++i) {
        fst[i] *= snd[i];
    }
    FFT(fst, true);
    for (size_t i = 0; i < fst.size(); ++i) {
        res[i] += static_cast<int>(fst[i].real() + 0.5);
    }
}

std::vector<int> GetMask(const std::string& data, char letter, size_t size) {
    std::vector<int> mask(size);
    for (size_t i = 0; i < data.size(); ++i) {
        if (data[i] == letter) {
            mask[i] = 1;
        }
    }
    return mask;
}

void DataForOneLetter(const std::string& text, const std::string& pattern,
    char letter, size_t algoSize, std::vector<int>& matchesCounter) {
    auto maskText = GetMask(text, letter, text.size());
    std::reverse(maskText.begin(), maskText.end());
    auto maskPattern = GetMask(pattern, letter, text.size());
    maskText.resize(algoSize);
    maskPattern.resize(algoSize);
    Multiply(maskText, maskPattern, matchesCounter);
}

size_t Solve(const std::string& text, const std::string& pattern) {
    size_t algoSize = 1;
    while (algoSize < text.size()) {
        algoSize <<= 1;
    }
    algoSize <<= 1;
    std::vector<int> matchesCounter(algoSize);
    for (auto letter : {'A', 'G', 'T', 'C'}) {
        DataForOneLetter(text, pattern, letter, algoSize, matchesCounter);
    }
    size_t maxPosition = 0;
    int value = -1;
    for (size_t i = pattern.size() - 1; i < text.size(); ++i) {
        if (matchesCounter[i] >= value) {
            maxPosition = text.size() - 1 - i;
            value = matchesCounter[i];
        }
    }
    return maxPosition + 1;
}

int main() {
    std::ios_base::sync_with_stdio(false);
    std::string text, pattern;
    std::cin >> text >> pattern;
    std::cout << Solve(text, pattern) << "\n";
    return 0;
}
