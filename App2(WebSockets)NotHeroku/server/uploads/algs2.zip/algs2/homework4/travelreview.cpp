#include <algorithm>
#include <iostream>
#include <vector>
#include <queue>
#include <utility>
#include <numeric>
#include <functional>
#include <iterator>

struct Edge {
    int source;
    int destination;
};

struct EdgeProperties {
    int capacity;
    int flow;
};

template <class Iterator>
class IteratorRange {
public:
    IteratorRange(Iterator begin, Iterator end) : begin_(begin), end_(end) {}

    Iterator begin() const { return begin_; }
    Iterator end() const { return end_; }

private:
    Iterator begin_, end_;
};

class Graph {
public:
    explicit Graph(size_t vertices_num) {
        adjacency_lists_.resize(vertices_num);
    }
    void AddEdge(int source, int dest) {
        adjacency_lists_[source].push_back(edges_.size());
        edges_.push_back({source, dest});
    }
    IteratorRange<std::vector<int>::const_iterator> GetOutgoingEdges(int source) const {
        return {adjacency_lists_[source].begin(), adjacency_lists_[source].end()};
    }
    int GetTarget(int edge_id) const {
        return edges_[edge_id].destination;
    }
    int GetSource(int edge_id) const {
        return edges_[edge_id].source;
    }
    size_t VertexCount() const {
        return adjacency_lists_.size();
    }

private:
    std::vector<std::vector<int>> adjacency_lists_;
    std::vector<Edge> edges_;
};

template <class Iterator, class Predicate>
class FilterIterator {
public:
    typedef typename std::iterator_traits<Iterator>::reference reference;
    FilterIterator(Iterator begin, Iterator end, Predicate predicate)
        : begin_(begin), end_(end), predicate_(predicate) {}
    Iterator Begin() {
        begin_ = std::find_if(begin_, end_, predicate_);
        return begin_;
    }
    FilterIterator& operator++() {
        if (begin_ == end_) {
            return *this;
        }
        ++begin_ = std::find_if(begin_, end_, predicate_);
        return *this;
    }
    reference operator*() const {
        return *begin_;
    }
    bool operator!=(FilterIterator elem) {
        return begin_ != elem.Begin();
    }
private:
    Iterator begin_, end_;
    Predicate predicate_;
};

template <class Predicate>
class FilteredGraph {
public:
    FilteredGraph(Graph graph, Predicate predicate)
        : graph_(graph), predicate_(predicate) {}
    IteratorRange<FilterIterator<std::vector<int>::const_iterator, Predicate>>
        GetOutgoingEdges(int source) const {
        auto edges = graph_.GetOutgoingEdges(source);
        auto begin = FilterIterator<std::vector<int>::const_iterator, Predicate>
            (edges.begin(), edges.end(), predicate_);
        auto end = FilterIterator<std::vector<int>::const_iterator, Predicate>
            (edges.end(), edges.end(), predicate_);
        return {begin, end};
    }
    int GetTarget(int edge_id) const {
        return graph_.GetTarget(edge_id);
    }
    int GetSource(int edge_id) const {
        return graph_.GetSource(edge_id);
    }
    size_t VertexCount() const {
        return graph_.VertexCount();
    }

private:
    Graph graph_;
    Predicate predicate_;
};

template <class Graph>
class BFSVisitor {
public:
    explicit BFSVisitor(std::vector<int>* dist)
        : distance_(*dist) {}
    void ExamineEdge(int edge_id, const Graph& graph) {
        distance_[graph.GetTarget(edge_id)] = distance_[graph.GetSource(edge_id)] + 1;
    }
    bool IsVisited(int vertex) {
        return distance_[vertex] != -1;
    }
    void DiscoverVertex(int vertex) {
        distance_[vertex] = 0;
    }
    void Update() {
        distance_.assign(distance_.size(), -1);
    }

private:
    std::vector<int>& distance_;
};

template <class Graph, class Visitor>
void BreadthFirstSearch(int origin_vertex, const Graph& graph,
                        Visitor visitor) {
    visitor.Update();
    std::queue<int> order({origin_vertex});
    visitor.DiscoverVertex(origin_vertex);
    while (!order.empty()) {
        auto source = order.front();
        order.pop();
        for (auto& edge : graph.GetOutgoingEdges(source)) {
            auto target = graph.GetTarget(edge);
            if (!visitor.IsVisited(target)) {
                visitor.DiscoverVertex(target);
                visitor.ExamineEdge(edge, graph);
                order.push(target);
            }
        }
    }
}

class FlowNetwork {
public:
    FlowNetwork(Graph& graph, int source, int sink, std::vector<EdgeProperties>& edges_properties)
        : graph_(graph), source_(source), sink_(sink), edges_properties_(edges_properties) {}
    FilteredGraph<std::function<bool(int)>> ResidualNetworkView() const {
        return FilteredGraph<std::function<bool(int)>>(graph_, [&](int edge_id) {
            return edges_properties_[edge_id].capacity > edges_properties_[edge_id].flow;
        });
    }
    void SendFlow(int edge_id, int pushed) {
        edges_properties_[edge_id].flow += pushed;
        edges_properties_[edge_id ^ 1].flow -= pushed;
    }
    int PushFlow(std::vector<std::vector<int>::const_iterator>& ptrs, const std::vector<int>& distance,
        int start, int flow) {
        if (start == sink_ || flow == 0) {
            return flow;
        }
        auto edges = graph_.GetOutgoingEdges(start);
        while (ptrs[start] != graph_.GetOutgoingEdges(start).end()) {
            int id = *ptrs[start], target = graph_.GetTarget(id);
            if (distance[target] != distance[start] + 1) {
                ++ptrs[start];
                continue;
            }
            int pushed = PushFlow(ptrs, distance, target,
                std::min(edges_properties_[id].capacity - edges_properties_[id].flow, flow));
            if (pushed > 0) {
                SendFlow(id, pushed);
                return pushed;
            }
            ++ptrs[start];
        }
        return 0;
    }
    void InitializePointers(std::vector<std::vector<int>::const_iterator>& pointers) {
        for (int i = 0; i < static_cast<int>(pointers.size()); ++i) {
            pointers[i] = graph_.GetOutgoingEdges(i).begin();
        }
    }
    int Dinic() {
        int answer = 0;
        std::vector<int> distance(graph_.VertexCount());
        std::vector<std::vector<int>::const_iterator> pointers(graph_.VertexCount());
        do {
            InitializePointers(pointers);
            BFSVisitor<FilteredGraph<std::function<bool(int)>>> visitor(&distance);
            BreadthFirstSearch(source_, ResidualNetworkView(), visitor);
            while (int pushed = PushFlow(pointers, distance, source_, inf_)) {
                answer += pushed;
            }
        } while (distance[sink_] != -1);
        return answer;
    }

    friend class FlowNetworkBuilder;
private:
    Graph graph_;
    int source_, sink_;
    std::vector<EdgeProperties> edges_properties_;
    const int inf_ = 100000000;
};

class FlowNetworkBuilder {
public:
    explicit FlowNetworkBuilder(size_t vertices_num) : graph_(vertices_num) {
        source_ = 0;
        sink_ = vertices_num - 1;
    }
    void AddEdge(int source, int destination, int capacity) {
        graph_.AddEdge(source, destination);
        edges_properties_.push_back({capacity, 0});
        graph_.AddEdge(destination, source);
        edges_properties_.push_back({0, 0});
    }
    FlowNetwork Build() {
        return {graph_, source_, sink_, edges_properties_};
    }
    int GetSource() const {
        return source_;
    }
    int GetSink() const {
        return sink_;
    }

private:
    Graph graph_;
    int source_, sink_;
    std::vector<EdgeProperties> edges_properties_;
};

template<class Predicate>
int BinSearch(int begin, int end, Predicate predicate) {
    // finds least iterator from [begin, end) such that predicate(iterator) = true
    // if there is no such iterator, returns end
    int left = begin, right = end;
    while (right > left) {
        int middle = left + (right - left) / 2;
        if (predicate(middle)) {
            right = middle;
        } else {
            left = middle + 1;
        }
    }
    return left;
}

struct Input {
    std::vector<int> gold;
    std::vector<std::pair<int, int>> relations;
};

FlowNetwork BuildNetworkForParticularNumberOfGold(const Input& input, int gold_number) {
    int people_num = static_cast<int>(input.gold.size());
    int maximum_gold = *std::max_element(input.gold.begin(), input.gold.end());
    FlowNetworkBuilder builder(people_num + 2);
    for (int i = 0; i < people_num; ++i) {
        builder.AddEdge(builder.GetSource(), i + 1, input.gold[i]);
    }
    for (int i = 0; i < people_num; ++i) {
        builder.AddEdge(i + 1, builder.GetSink(), gold_number);
    }
    for (const auto& edge : input.relations) {
        builder.AddEdge(edge.first, edge.second, maximum_gold);
    }
    return builder.Build();
}

int FindOptimalNumberOfGoldOfBusiestPerson(const Input& input) {
    int maximum_gold = *std::max_element(input.gold.begin(), input.gold.end());
    int total_gold = std::accumulate(input.gold.begin(), input.gold.end(), 0);
    return BinSearch(0, maximum_gold, [&](int gold_number) {
        auto network = BuildNetworkForParticularNumberOfGold(input, gold_number);
        return network.Dinic() == total_gold;
    });
}

std::vector<int> ReadArray(size_t size, std::istream& in = std::cin) {
    std::vector<int> result(size);
    for (int& elem : result) {
        in >> elem;
    }
    return result;
}

std::vector<std::pair<int, int>> ReadEdges(size_t edges_num, std::istream& in = std::cin) {
    std::vector<std::pair<int, int>> result(edges_num);
    for (auto& edge : result) {
        in >> edge.first >> edge.second;
    }
    return result;
}

Input ReadInput(std::istream& in = std::cin) {
    size_t people_num, edges_num;
    in >> people_num >> edges_num;
    return {ReadArray(people_num), ReadEdges(edges_num)};
}

int main() {
    std::ios_base::sync_with_stdio(false);
    auto input = ReadInput();
    std::cout << FindOptimalNumberOfGoldOfBusiestPerson(input) << "\n";
    return 0;
}
