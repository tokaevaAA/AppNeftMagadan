import random
import string

def randomString(stringLength=8):
    letters = ['A', 'G', 'T', 'C']
    return ''.join(random.choice(letters) for i in range(stringLength))

n, m = 200000, 100000

print(randomString(n))
print(randomString(m))