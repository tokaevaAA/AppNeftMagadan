#include <algorithm>
#include <iostream>
#include <vector>

std::vector<int> ReadVector(size_t size, std::istream& in = std::cin) {
    std::vector<int> result(size);
    for (int& elem : result) {
        in >> elem;
    }
    return result;
}

std::vector<std::vector<int>> ReadMatrix(size_t size, std::istream& in = std::cin) {
    std::vector<std::vector<int>> result(size, std::vector<int>(size));
    for (auto& row : result) {
        for (int& elem : row) {
            in >> elem;
        }
    }
    return result;
}

struct Edge {
    int src;
    int dest;
    int cap;
    int flow;
};

class Graph {
public:
    explicit Graph(int verticesNum) {
        adjLists_.resize(verticesNum * verticesNum + verticesNum + 2);
        source_ = verticesNum - 1;
        sink_ = verticesNum;
    }
    void AddEdge(int src, int dest, int capacity) {
        adjLists_[src].push_back(edges_.size());
        edges_.push_back({src, dest, capacity, 0});
        adjLists_[dest].push_back(edges_.size());
        edges_.push_back({dest, src, 0, 0});
    }
    int DFS(int currVertex, int currFlow, std::vector<bool>& used) {
        used[currVertex] = true;
        if (currFlow == 0) {
            return 0;
        }
        if (currVertex == sink_) {
            return currFlow;
        }
        for (int id : adjLists_[currVertex]) {
            int dest = edges_[id].dest, capacity = edges_[id].cap, flow = edges_[id].flow;
            if (!used[dest] && capacity - flow > 0) {
                int pushed = DFS(dest, std::min(capacity - flow, currFlow), used);
                if (pushed) {
                    edges_[id].flow += pushed;
                    edges_[id ^ 1].flow -= pushed;
                    return pushed;
                }
            }
        }
        return 0;
    }
    int GetFlow() {
        std::vector<bool> used(adjLists_.size(), false);
        int currFlow = 0;
        while (int pushed = DFS(source_, INF_, used)) {
            currFlow += pushed;
            used.assign(adjLists_.size(), false);
        }
        return currFlow;
    }

private:
    std::vector<Edge> edges_;
    std::vector<std::vector<int>> adjLists_;
    int source_, sink_;
    const int INF_ = 100000000;
};

bool Solve(const std::vector<int>& wins, const std::vector<int>& rgames,
    const std::vector<std::vector<int>>& games) {
    int teamsNum = static_cast<int>(wins.size());
    Graph graph(teamsNum);
    for (int i = 0; i < teamsNum - 1; ++i) {
        if (wins[0] + rgames[0] - wins[i + 1] < 0) {
            return false;
        }
        graph.AddEdge(i, teamsNum, wins[0] + rgames[0] - wins[i + 1]);
    }
    int currNumber = teamsNum + 1, gamesToPlay = 0;
    for (int i = 1; i < teamsNum; ++i) {
        for (int j = 1; j < i; ++j) {
            if (games[i][j]) {
                graph.AddEdge(teamsNum - 1, currNumber, games[i][j]);
                graph.AddEdge(currNumber, i - 1, games[i][j]);
                graph.AddEdge(currNumber, j - 1, games[i][j]);
                ++currNumber;
                gamesToPlay += games[i][j];
            }
        }
    }
    return graph.GetFlow() == gamesToPlay;
}


int main() {
    std::ios_base::sync_with_stdio(false);
    size_t size;
    std::cin >> size;
    auto wins = ReadVector(size);
    auto rgames = ReadVector(size);
    auto games = ReadMatrix(size);
    if (Solve(wins, rgames, games)) {
        std::cout << "YES" << "\n";
    } else {
        std::cout << "NO" << "\n";
    }
    return 0;
}
