#include <algorithm>
#include <iostream>
#include <vector>

std::vector<int> ReadArray(size_t size, std::istream& in = std::cin) {
    std::vector<int> result(size);
    for (int& elem : result) {
        in >> elem;
    }
    return result;
}

std::vector<std::vector<int>> ReadGraph(size_t verticesNum, size_t edgesNum,
    std::istream& in = std::cin) {
    std::vector<std::vector<int>> graph(verticesNum << 1);
    for (size_t i = 0; i < edgesNum; ++i) {
        int first, second;
        in >> first >> second;
        graph[first - 1].push_back(second - 1 + verticesNum);
        graph[second - 1 + verticesNum].push_back(first - 1);
    }
    return graph;
}

void DFS(const std::vector<std::vector<int>>& graph, std::vector<bool>& used,
    int vertex, std::vector<int>& component) {
    used[vertex] = true;
    component.push_back(vertex);
    for (const int& dest : graph[vertex]) {
        if (!used[dest]) {
            DFS(graph, used, dest, component);
        }
    }
}

int FlowFromComponent(const std::vector<int>& component, int verticesNum,
    const std::vector<int>& lhs, const std::vector<int>& rhs) {
    int lhsFlow = 0, rhsFlow = 0;
    for (const int elem : component) {
        if (elem < verticesNum) {
            lhsFlow += lhs[elem];
        } else {
            rhsFlow += rhs[elem - verticesNum];
        }
    }
    return std::min(lhsFlow, rhsFlow);
}

int Solve(const std::vector<std::vector<int>>& graph, const std::vector<int>& lhs,
    const std::vector<int>& rhs) {
    std::vector<bool> used(graph.size(), false);
    std::vector<int> component;
    int answer = 0;
    for (int i = 0; i < static_cast<int>(graph.size()); ++i) {
        if (!used[i]) {
            DFS(graph, used, i, component);
            answer += FlowFromComponent(component, lhs.size(), lhs, rhs);
            component.clear();
        }
    }
    return answer;
}

int main() {
    std::ios_base::sync_with_stdio(false);
    size_t verticesNum, edgesNum;
    std::cin >> verticesNum >> edgesNum;
    auto lhs = ReadArray(verticesNum);
    auto rhs = ReadArray(verticesNum);
    auto graph = ReadGraph(verticesNum, edgesNum);
    std::cout << Solve(graph, lhs, rhs) << "\n";
    return 0;
}
