#include <algorithm>
#include <iostream>
#include <vector>
#include <queue>

struct Edge {
    int src;
    int dest;
    int flow;
    int capacity;
};

std::vector<int> BFS(const std::vector<Edge>& edges,
    const std::vector<std::vector<int>>& graph, int source, int sink) {
    std::vector<int> dist(graph.size(), -1);
    std::queue<int> order({source});
    dist[source] = 0;
    while (!order.empty()) {
        int currVertex = order.front();
        order.pop();
        for (int id : graph[currVertex]) {
            if (dist[edges[id].dest] == -1 && edges[id].capacity - edges[id].flow > 0) {
                dist[edges[id].dest] = dist[currVertex] + 1;
                order.push(edges[id].dest);
            }
        }
    }
    return dist;
}

int DFS(std::vector<Edge>& edges, std::vector<int>& pointers, const std::vector<int>& dist,
    const std::vector<std::vector<int>>& graph, int start, int sink, int flow) {
    if (flow == 0) {
        return 0;
    }
    if (start == sink) {
        return flow;
    }
    while (static_cast<size_t>(pointers[start]) < graph[start].size()) {
        int id = graph[start][pointers[start]];
        int target = edges[id].dest;
        if (dist[target] != dist[start] + 1) {
            ++pointers[start];
            continue;
        }
        int pushed = DFS(edges, pointers, dist, graph, target, sink,
            std::min(edges[id].capacity - edges[id].flow, flow));
        if (pushed) {
            edges[id].flow += pushed;
            edges[id ^ 1].flow -= pushed;
            return pushed;
        }
        ++pointers[start];
    }
    return 0;
}

int Dinic(const std::vector<std::vector<int>>& graph, std::vector<Edge>& edges,
    int source, int sink) {
    int answer = 0;
    std::vector<int> pointers(graph.size());
    for (;;) {
        pointers.assign(graph.size(), 0);
        auto dist = BFS(edges, graph, source, sink);
        if (dist[sink] == -1) {
            return answer;
        }
        while (int pushed = DFS(edges, pointers, dist, graph, source, sink, 1e8)) {
            answer += pushed;
        }
    }
    return answer;
}

void AddEdge(std::vector<Edge>& edges, std::vector<std::vector<int>>& graph,
    int src, int dest, int capacity) {
    graph[src].push_back(edges.size());
    edges.push_back({src, dest, 0, capacity});
    graph[dest].push_back(edges.size());
    edges.push_back({dest, src, 0, 0});
}

std::vector<int> ReadVector(size_t size, std::istream& in = std::cin) {
    std::vector<int> answer(size);
    for (auto& elem : answer) {
        in >> elem;
    }
    return answer;
}

int main() {
    return 0;
}