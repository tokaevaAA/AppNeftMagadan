#include <algorithm>
#include <fstream>
#include <iostream>
#include <iterator>
#include <vector>

template<class T>
void PrintVectorAsMatrix(const std::vector<T>& data, size_t cols,
    std::ostream& out = std::cout) {
    for (auto it = data.begin(); it < data.end(); it += cols) {
        std::copy(it, it + cols, std::ostream_iterator<T>(out, " "));
        out << std::endl;
    }
}

template<class T>
void PrintVectors(const std::vector<T>& first, const std::vector<T>& second,
    const std::vector<T>& third, std::ostream& out = std::cout) {
    for (auto it_first = first.begin(), it_second = second.begin(), it_third = third.begin();
        it_first < first.end(); ++it_first, ++it_second, ++it_third) {
        out << *it_first << " " << *it_second << " " << *it_third << std::endl;
    }
}

int main() {
    std::vector<double> data = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12};
    std::ofstream fs("logs.txt");
    PrintVectorAsMatrix(data, 4, fs);
    return 0;
}
