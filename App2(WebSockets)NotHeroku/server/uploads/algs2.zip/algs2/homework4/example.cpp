#include <iterator>
#include <vector>
#include <iostream>
#include <functional>

template <class Iterator, class Predicate>
class FilterIterator {
public:
    explicit FilterIterator(Iterator begin, Iterator end, std::function<bool(int)> predicate)
        : begin_(begin), end_(end), predicate_(predicate) {}
    Iterator Begin() const { return begin_; }
    Iterator End() const { return end_; }
    FilterIterator& operator++() {
        ++begin_;
        while (begin_ != end_ && !predicate_(*begin_)) {
            ++begin_;
        }
        return *this;
    }
    typename std::iterator_traits<Iterator>::reference operator*() const {
        return *begin_;
    }
private:
    Iterator begin_, end_;
    Predicate predicate_;
};

template<class Iterator, class Predicate>
class A {
public:
    FilterIterator<Iterator, Predicate> GetIterator() {
        return FilterIterator<Iterator, Predicate>(arr[0].begin(), arr[0].end(), [](int elem) {
            return elem > 2;
        });
    }
private:
    std::vector<std::vector<int>> arr = {{10, 2, 3}, {2, 3}};
};

int main() {
    A<std::vector<int>::iterator, std::function<bool(int)>> a;
    auto it = a.GetIterator();
    std::cout << *it << std::endl;
    ++it;
    std::cout << *it << std::endl;
    ++it;
    return 0;
}