#include <algorithm>
#include <iostream>
#include <vector>
#include <queue>
#include <utility>
#include <numeric>
#include <functional>
#include <iterator>

struct Edge {
    int source;
    int destination;
    int id;
};

struct EdgeProperties {
    int capacity;
    int flow;
};

template <class Iterator>
class IteratorRange {
public:
    IteratorRange(Iterator begin, Iterator end) : begin_(begin), end_(end) {}

    Iterator begin() const { return begin_; } // NOLINT
    Iterator end() const { return end_; } // NOLINT

private:
    Iterator begin_, end_;
};

class Graph {
public:
    explicit Graph(size_t vertices_num) {
        adjacency_lists_.resize(vertices_num);
    }
    void AddEdge(int source, int destination) {
        adjacency_lists_[source].push_back({source, destination, current_id_});
        ++current_id_;
    }
    IteratorRange<std::vector<Edge>::const_iterator> GetOutgoingEdges(int source) const {
        return {adjacency_lists_[source].begin(), adjacency_lists_[source].end()};
    }
    int GetTarget(Edge edge) const {
        return edge.destination;
    }
    int GetSource(Edge edge) const {
        return edge.source;
    }
    size_t VertexCount() const {
        return adjacency_lists_.size();
    }

private:
    int current_id_ = 0;
    std::vector<std::vector<Edge>> adjacency_lists_;
};

template <class Iterator, class Predicate>
class FilterIterator {
public:
    typedef typename std::iterator_traits<Iterator>::reference reference; // NOLINT
    FilterIterator(Iterator begin, Iterator end, Predicate predicate)
        : begin_(begin), end_(end), predicate_(predicate) {
        begin_ = std::find_if(begin_, end_, predicate_);
    }
    Iterator Begin() const {
        return begin_;
    }
    FilterIterator& operator++() {
        if (begin_ == end_) {
            return *this;
        }
        ++begin_;
        begin_ = std::find_if(begin_, end_, predicate_);
        return *this;
    }
    reference operator*() const {
        return *begin_;
    }
    bool operator!=(FilterIterator elem) {
        return begin_ != elem.Begin();
    }

private:
    Iterator begin_, end_;
    Predicate predicate_;
};

template <class Predicate>
class FilteredGraph {
public:
    FilteredGraph(Graph graph, Predicate predicate)
        : graph_(graph), predicate_(predicate) {}
    IteratorRange<FilterIterator<std::vector<Edge>::const_iterator, Predicate>>
        GetOutgoingEdges(int source) const {
        auto edges = graph_.GetOutgoingEdges(source);
        auto begin = FilterIterator<std::vector<Edge>::const_iterator, Predicate>
            (edges.begin(), edges.end(), predicate_);
        auto end = FilterIterator<std::vector<Edge>::const_iterator, Predicate>
            (edges.end(), edges.end(), predicate_);
        return {begin, end};
    }
    int GetTarget(Edge edge) const {
        return graph_.GetTarget(edge);
    }
    int GetSource(Edge edge) const {
        return graph_.GetSource(edge);
    }
    size_t VertexCount() const {
        return graph_.VertexCount();
    }

private:
    Graph graph_;
    Predicate predicate_;
};

template <class Graph>
class BFSVisitor {
public:
    explicit BFSVisitor(std::vector<int>* dist)
        : distance_(*dist) {}
    void ExamineEdge(Edge edge, const Graph& graph) {
        distance_[graph.GetTarget(edge)] = distance_[graph.GetSource(edge)] + 1;
    }
    bool IsVisited(int vertex) {
        return distance_[vertex] != -1;
    }
    void DiscoverVertex(int vertex) {
        distance_[vertex] = 0;
    }
    void Update() {
        distance_.assign(distance_.size(), -1);
    }

private:
    std::vector<int>& distance_;
};

template <class Graph, class Visitor>
void BreadthFirstSearch(int origin_vertex, const Graph& graph,
                        Visitor visitor) {
    visitor.Update();
    std::queue<int> order({origin_vertex});
    visitor.DiscoverVertex(origin_vertex);
    while (!order.empty()) {
        auto source = order.front();
        order.pop();
        for (auto& edge : graph.GetOutgoingEdges(source)) {
            auto target = graph.GetTarget(edge);
            if (!visitor.IsVisited(target)) {
                visitor.DiscoverVertex(target);
                visitor.ExamineEdge(edge, graph);
                order.push(target);
            }
        }
    }
}

class FlowNetwork {
public:
    FlowNetwork(Graph& graph, int source, int sink, int maximum_flow,
        std::vector<EdgeProperties>& edges_properties)
        : graph_(graph),
          source_(source),
          sink_(sink),
          maximum_flow_(maximum_flow),
          edges_properties_(edges_properties) {}
    FilteredGraph<std::function<bool(Edge)>> ResidualNetworkView() const {
        return FilteredGraph<std::function<bool(Edge)>>(graph_, [&](Edge edge) {
            return edges_properties_[edge.id].capacity > edges_properties_[edge.id].flow;
        });
    }
    void SendFlow(Edge edge, int pushed) {
        edges_properties_[edge.id].flow += pushed;
        edges_properties_[edge.id ^ 1].flow -= pushed;
    }
    const Graph& GetGraph() const {
        return graph_;
    }
    int GetSource() const {
        return source_;
    }
    int GetMaximumFlow() const {
        return maximum_flow_;
    }
    int GetSink() const {
        return sink_;
    }
    int GetResidualCapacity(Edge edge) const {
        return edges_properties_[edge.id].capacity - edges_properties_[edge.id].flow;
    }

    friend class FlowNetworkBuilder;
private:
    Graph graph_;
    int source_, sink_, maximum_flow_;
    std::vector<EdgeProperties> edges_properties_;
};

void InitializePointers(const FlowNetwork& network,
    std::vector<std::vector<Edge>::const_iterator>& pointers) {
    for (int i = 0; i < static_cast<int>(pointers.size()); ++i) {
        pointers[i] = network.GetGraph().GetOutgoingEdges(i).begin();
    }
}

int PushFlow(FlowNetwork& network, std::vector<std::vector<Edge>::const_iterator>& ptrs,
    const std::vector<int>& distance, int start, int flow) {
    if (start == network.GetSink() || flow == 0) {
        return flow;
    }
    while (ptrs[start] != network.GetGraph().GetOutgoingEdges(start).end()) {
        int target = network.GetGraph().GetTarget(*ptrs[start]);
        if (distance[target] != distance[start] + 1) {
            ++ptrs[start];
            continue;
        }
        int pushed = PushFlow(network, ptrs, distance, target,
            std::min(network.GetResidualCapacity(*ptrs[start]), flow));
        if (pushed > 0) {
            network.SendFlow(*ptrs[start], pushed);
            return pushed;
        }
        ++ptrs[start];
    }
    return 0;
}

int Dinic(FlowNetwork& network) {
    int answer = 0;
    std::vector<int> distance(network.GetGraph().VertexCount());
    std::vector<std::vector<Edge>::const_iterator> pointers(network.GetGraph().VertexCount());
    do {
        InitializePointers(network, pointers);
        BFSVisitor<FilteredGraph<std::function<bool(Edge)>>> visitor(&distance);
        BreadthFirstSearch(network.GetSource(), network.ResidualNetworkView(), visitor);
        while (int pushed = PushFlow(network, pointers, distance,
            network.GetSource(), network.GetMaximumFlow())) {
            answer += pushed;
        }
    } while (distance[network.GetSink()] != -1);
    return answer;
}

class FlowNetworkBuilder {
public:
    explicit FlowNetworkBuilder(size_t vertices_num, int maximum_flow)
        : graph_(vertices_num), maximum_flow_(maximum_flow) {
        source_ = 0;
        sink_ = vertices_num - 1;
    }
    void AddEdge(int source, int destination, int capacity) {
        graph_.AddEdge(source, destination);
        edges_properties_.push_back({capacity, 0});
        graph_.AddEdge(destination, source);
        edges_properties_.push_back({0, 0});
    }
    FlowNetwork Build() {
        return {graph_, source_, sink_, maximum_flow_, edges_properties_};
    }
    int GetSource() const {
        return source_;
    }
    int GetSink() const {
        return sink_;
    }

private:
    Graph graph_;
    int source_, sink_, maximum_flow_;
    std::vector<EdgeProperties> edges_properties_;
};

template<class Predicate>
int BinSearch(int begin, int end, Predicate predicate) {
    // finds least iterator from [begin, end) such that predicate(iterator) = true
    // if there is no such iterator, returns end
    int left = begin, right = end;
    while (right > left) {
        int middle = left + (right - left) / 2;
        if (predicate(middle)) {
            right = middle;
        } else {
            left = middle + 1;
        }
    }
    return left;
}

struct Input {
    std::vector<int> gold;
    std::vector<std::pair<int, int>> relations;
};

FlowNetwork BuildNetworkForParticularNumberOfGold(const Input& input, int gold_number) {
    int people_num = static_cast<int>(input.gold.size());
    int maximum_gold = *std::max_element(input.gold.begin(), input.gold.end());
    FlowNetworkBuilder builder(people_num + 2, maximum_gold);
    for (int i = 0; i < people_num; ++i) {
        builder.AddEdge(builder.GetSource(), i + 1, input.gold[i]);
    }
    for (int i = 0; i < people_num; ++i) {
        builder.AddEdge(i + 1, builder.GetSink(), gold_number);
    }
    for (const auto& edge : input.relations) {
        builder.AddEdge(edge.first, edge.second, maximum_gold);
    }
    return builder.Build();
}

int FindOptimalNumberOfGoldOfBusiestPerson(const Input& input) {
    int maximum_gold = *std::max_element(input.gold.begin(), input.gold.end());
    int total_gold = std::accumulate(input.gold.begin(), input.gold.end(), 0);
    return BinSearch(0, maximum_gold, [&](int gold_number) {
        auto network = BuildNetworkForParticularNumberOfGold(input, gold_number);
        return Dinic(network) == total_gold;
    });
}

std::vector<int> ReadArray(size_t size, std::istream& in = std::cin) {
    std::vector<int> result(size);
    for (int& elem : result) {
        in >> elem;
    }
    return result;
}

std::vector<std::pair<int, int>> ReadEdges(size_t edges_num, std::istream& in = std::cin) {
    std::vector<std::pair<int, int>> result(edges_num);
    for (auto& edge : result) {
        in >> edge.first >> edge.second;
    }
    return result;
}

Input ReadInput(std::istream& in = std::cin) {
    size_t people_num, edges_num;
    in >> people_num >> edges_num;
    return {ReadArray(people_num), ReadEdges(edges_num)};
}

int main() {
    std::ios_base::sync_with_stdio(false);
    auto input = ReadInput();
    std::cout << FindOptimalNumberOfGoldOfBusiestPerson(input) << "\n";
    return 0;
}
