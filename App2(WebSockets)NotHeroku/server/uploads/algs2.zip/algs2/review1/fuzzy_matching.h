#include <algorithm>
#include <cstring>
#include <deque>
#include <iostream>
#include <iterator>
#include <map>
#include <memory>
#include <queue>
#include <sstream>
#include <string>
#include <unordered_set>
#include <unordered_map>
#include <random>
#include <vector>
#include <chrono>

template <class Iterator>
class IteratorRange {
public:
    IteratorRange(Iterator begin, Iterator end) : begin_(begin), end_(end) {}

    Iterator begin() const { return begin_; }
    Iterator end() const { return end_; }

private:
    Iterator begin_, end_;
};

namespace traverses {
template <class Vertex, class Graph, class Visitor>
void BreadthFirstSearch(Vertex origin_vertex, const Graph &graph,
                        Visitor visitor) {
    std::queue<Vertex> order({origin_vertex});
    std::unordered_set<Vertex> used({origin_vertex});
    visitor.DiscoverVertex(origin_vertex);
    while (!order.empty()) {
        auto source = order.front();
        order.pop();
        visitor.ExamineVertex(source);
        for (auto edge : OutgoingEdges(graph, source)) {
            visitor.ExamineEdge(edge);
            auto target = GetTarget(graph, edge);
            if (used.find(target) == used.end()) {
                visitor.DiscoverVertex(target);
                order.push(target);
                used.insert(target);
            }
        }
    }
}

template <class Vertex, class Edge>
class BfsVisitor {
public:
    virtual void DiscoverVertex(Vertex /*vertex*/) {}
    virtual void ExamineEdge(const Edge & /*edge*/) {}
    virtual void ExamineVertex(Vertex /*vertex*/) {}
    virtual ~BfsVisitor() = default;
};

} // namespace traverses

namespace aho_corasick {

struct AutomatonNode {
    AutomatonNode() : suffix_link(nullptr), terminal_link(nullptr) {}

    std::vector<size_t> terminated_string_ids;
    std::map<char, AutomatonNode> trie_transitions;
    std::map<char, AutomatonNode *> automaton_transitions_cache;
    AutomatonNode *suffix_link;
    AutomatonNode *terminal_link;
};

// Returns a corresponding trie transition 'nullptr' otherwise.
AutomatonNode *GetTrieTransition(AutomatonNode *node, char character) {
    if (node->trie_transitions.find(character) != node->trie_transitions.end()) {
        return &node->trie_transitions[character];
    }
    return nullptr;
}

// Returns an automaton transition, updates 'node->automaton_transitions_cache'
// if necessary.
// Provides constant amortized runtime.
AutomatonNode *GetAutomatonTransition(AutomatonNode *node,
                                      const AutomatonNode *root,
                                      char character) {
    if (GetTrieTransition(node, character)) {
        return &node->trie_transitions[character];
    }
    if (node == root) {
        return node;
    }
    if (node->automaton_transitions_cache.find(character) 
    != node->automaton_transitions_cache.end()) {
        return node->automaton_transitions_cache[character];    
    }
    auto transition = GetAutomatonTransition(node->suffix_link, root, character);
    node->automaton_transitions_cache[character] = transition;
    return transition;
}

namespace internal {

class AutomatonGraph {
public:
    struct Edge {
        Edge(AutomatonNode *source, AutomatonNode *target, char character)
            : source(source), target(target), character(character) {}

        AutomatonNode *source;
        AutomatonNode *target;
        char character;
    };
};

std::vector<typename AutomatonGraph::Edge> OutgoingEdges(
        const AutomatonGraph & /*graph*/, AutomatonNode *vertex) {
    std::vector<typename AutomatonGraph::Edge> outgoing_edges;
    for (auto& destination : vertex->trie_transitions) {
        outgoing_edges.push_back({vertex, &destination.second, destination.first});
    }
    return outgoing_edges;
}

AutomatonNode *GetTarget(const AutomatonGraph & /*graph*/,
                         const AutomatonGraph::Edge &edge) {
    return edge.target;
}

class SuffixLinkCalculator
        : public traverses::BfsVisitor<AutomatonNode *, AutomatonGraph::Edge> {
public:
    explicit SuffixLinkCalculator(AutomatonNode *root) : root_(root) {}

    void ExamineVertex(AutomatonNode *node) override {}

    void ExamineEdge(const AutomatonGraph::Edge &edge) override {
        auto current_link = edge.source->suffix_link;
        while (current_link && !GetTrieTransition(current_link, edge.character)) {
            current_link = current_link->suffix_link;
        }
        if (current_link) {
            edge.target->suffix_link = &current_link->trie_transitions[edge.character]; 
        } else {
            edge.target->suffix_link = root_;
        }
    }

private:
    AutomatonNode *root_;
};

class TerminalLinkCalculator
        : public traverses::BfsVisitor<AutomatonNode *, AutomatonGraph::Edge> {
public:
    explicit TerminalLinkCalculator(AutomatonNode *root) : root_(root) {}

    void DiscoverVertex(AutomatonNode *node) override {
        if (node->suffix_link && node->suffix_link->terminated_string_ids.empty()) {
            node->terminal_link = node->suffix_link->terminal_link;
        } else {
            node->terminal_link = node->suffix_link;
        }
    }

private:
    AutomatonNode *root_;
};

} // namespace internal


class NodeReference {
public:
    NodeReference() : node_(nullptr), root_(nullptr) {}

    NodeReference(AutomatonNode *node, AutomatonNode *root)
        : node_(node), root_(root) {}

    NodeReference Next(char character) const {
        return {GetAutomatonTransition(node_, root_, character), root_};
    }

    template <class Callback>
    void GenerateMatches(Callback on_match) const {
        auto current = node_;
        while (current) {
            for (auto id : current->terminated_string_ids) {
                on_match(id);
            }
            current = current->terminal_link;
        }
    }

    explicit operator bool() const { return node_ != nullptr; }

private:
    using TerminatedStringIterator = std::vector<size_t>::const_iterator;
    using TerminatedStringIteratorRange = IteratorRange<TerminatedStringIterator>;

    AutomatonNode *node_;
    AutomatonNode *root_;
};

class AutomatonBuilder;

class Automaton {
public:
    Automaton() = default;

    Automaton(const Automaton &) = delete;
    Automaton &operator=(const Automaton &) = delete;

    NodeReference Root() {
        return {&root_, &root_};
    }

private:
    AutomatonNode root_;

    friend class AutomatonBuilder;
};

class AutomatonBuilder {
public:
    void Add(const std::string &string, size_t id) {
        words_.push_back(string);
        ids_.push_back(id);
    }

    std::unique_ptr<Automaton> Build() {
        auto automaton = std::make_unique<Automaton>();
        BuildTrie(words_, ids_, automaton.get());
        BuildSuffixLinks(automaton.get());
        BuildTerminalLinks(automaton.get());
        return automaton;
    }

private:
    static void BuildTrie(const std::vector<std::string> &words,
                          const std::vector<size_t> &ids, Automaton *automaton) {
        for (size_t i = 0; i < words.size(); ++i) {
            AddString(&automaton->root_, ids[i], words[i]);
        }
    }

    static void AddString(AutomatonNode *root, size_t string_id,
                          const std::string &string) {
        auto current = root;
        for (const char& letter : string) {
            if (!GetTrieTransition(current, letter)) {
                current->trie_transitions[letter] = AutomatonNode();
            }
            current = &current->trie_transitions[letter];
        }
        current->terminated_string_ids.push_back(string_id);
    }

    static void BuildSuffixLinks(Automaton *automaton) {
        aho_corasick::internal::SuffixLinkCalculator visitor(&automaton->root_);
        traverses::BreadthFirstSearch(&automaton->root_, aho_corasick::internal::AutomatonGraph() ,
                                      visitor);
    }

    static void BuildTerminalLinks(Automaton *automaton) {
        aho_corasick::internal::TerminalLinkCalculator visitor(&automaton->root_);
        traverses::BreadthFirstSearch(&automaton->root_, aho_corasick::internal::AutomatonGraph() ,
                                      visitor);
    }

    std::vector<std::string> words_;
    std::vector<size_t> ids_;
};

} // namespace aho_corasick

// Consecutive delimiters are not grouped together and are deemed
// to delimit empty strings
template <class Predicate>
std::vector<std::string> Split(const std::string &string,
                               Predicate is_delimiter) {
    std::vector<std::string> patterns;
    std::string pattern;
    for (const char& letter : string) {
        if (is_delimiter(letter)) {
            patterns.push_back(pattern);
            pattern.clear();
        } else {
            pattern.push_back(letter);
        }
    }
    patterns.push_back(pattern);
    return patterns;
}

// Wildcard is a character that may be substituted
// for any of all possible characters.
class WildcardMatcher {
public:
    WildcardMatcher() : number_of_words_(0), pattern_length_(0) {}

    WildcardMatcher static BuildFor(const std::string &pattern, char wildcard) {
        aho_corasick::AutomatonBuilder builder;
        WildcardMatcher matcher;
        size_t margin = 0;
        auto patterns = Split(pattern, [wildcard](char letter) { 
            return wildcard == letter; 
        });
        for (size_t i = 0; i < patterns.size(); ++i) {
            if (patterns[i].empty()) {
                ++margin;
                continue;
            }
            builder.Add(patterns[i], margin + patterns[i].size());
            ++matcher.number_of_words_;
            margin += 1 + patterns[i].size();
        }
        matcher.aho_corasick_automaton_ = builder.Build();
        matcher.state_ = matcher.aho_corasick_automaton_->Root();
        matcher.words_occurrences_by_position_ = {0};
        matcher.pattern_length_ = pattern.size();
        return matcher;
    }

    void Reset() {
        state_ = aho_corasick_automaton_->Root();
        words_occurrences_by_position_ = {0};
    }

    template <class Callback>
    void Scan(char character, Callback on_match) {
        state_ = state_.Next(character);
        UpdateWordOccurrencesCounters();
        auto back = words_occurrences_by_position_.back();
        if (back == number_of_words_
            && words_occurrences_by_position_.size() == pattern_length_) {
            on_match();
        }
        ShiftWordOccurrencesCounters();
    }

private:
    void UpdateWordOccurrencesCounters() {
        state_.GenerateMatches([&](size_t id) {
            if (words_occurrences_by_position_.size() >= id) {
                ++words_occurrences_by_position_[id - 1];
            }
        });
    }

    void ShiftWordOccurrencesCounters() {
        if (words_occurrences_by_position_.size() == pattern_length_) {
            words_occurrences_by_position_.pop_back();
        }
        words_occurrences_by_position_.push_front(0);
    }

    std::deque<size_t> words_occurrences_by_position_;
    aho_corasick::NodeReference state_;
    size_t number_of_words_;
    size_t pattern_length_;
    std::unique_ptr<aho_corasick::Automaton> aho_corasick_automaton_;
};

std::string ReadString(std::istream &input_stream) {
    std::string text;
    input_stream >> text;
    return text;
}

std::vector<size_t> FindFuzzyMatches(const std::string &pattern_with_wildcards,
                                     const std::string &text, char wildcard) {
    WildcardMatcher matcher = WildcardMatcher::BuildFor(pattern_with_wildcards, wildcard);
    std::vector<size_t> occurrences;
    for (size_t i = 0; i < text.size(); ++i) {
        matcher.Scan(text[i], [&occurrences, i]() { occurrences.push_back(i); });
    }
    std::for_each(occurrences.begin(), occurrences.end(), [&](size_t &occurence) {
        occurence -= pattern_with_wildcards.size() - 1;
    });
    return occurrences;
}

void Print(const std::vector<size_t> &sequence) {
    std::cout << sequence.size() << "\n";
    std::copy(sequence.begin(), sequence.end(), std::ostream_iterator<size_t>(std::cout, " "));
    std::cout << "\n";
}
