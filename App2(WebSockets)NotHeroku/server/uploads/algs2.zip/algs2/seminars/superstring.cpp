#include <algorithm>
#include <iostream>
#include <iterator>
#include <string>
#include <vector>

bool Contains(const std::string& pattern, const std::string& text) {
    for (auto textIt = text.begin(); textIt != text.end(); ++textIt) {
        auto patternPtr = pattern.begin(), textPtr = textIt;
        while (patternPtr != pattern.end() && textPtr != text.end() && *patternPtr == *textPtr) {
            ++patternPtr;
            ++textPtr;
        }
        if (patternPtr == pattern.end()) {
            return true;
        }
    }
    return false;
}

std::vector<std::string> FilterData(const std::vector<std::string>& data) {
    std::vector<std::string> filteredData;
    std::vector<bool> isDeleted(data.size(), false);
    for (size_t ind = 0; ind < data.size(); ++ind) {
        bool flag = true;
        for (size_t j = 0; j < data.size(); ++j) {
            if (!isDeleted[j] && j != ind && Contains(data[ind], data[j])) {
                flag = false;
            }
        }
        if (flag) {
            filteredData.push_back(data[ind]);
        } else {
            isDeleted[ind] = true;
        }
    }
    return filteredData;
}

size_t MaxOverlap(const std::string& first, const std::string& second) {
    for (auto firstIt = first.begin(); firstIt != first.end(); ++firstIt) {
        auto firstPtr = firstIt, secondPtr = second.begin();
        while (firstPtr != first.end() && *firstPtr == *secondPtr) {
            ++firstPtr;
            ++secondPtr;
        }
        if (firstPtr == first.end()) {
            return std::distance(firstIt, first.end());
        }
    }
    return 0;
}

std::string GetStringByIndexes(const std::vector<std::string>& data, size_t size,
    const std::vector<size_t>& indexes, const std::vector<std::vector<int>>& overlaps) {
    std::string superstring = data[indexes[0]];
    for (size_t i = 1; i < size; ++i) {
        superstring.append(data[indexes[i]].begin() + overlaps[indexes[i - 1]][indexes[i]],
            data[indexes[i]].end());
    }
    return superstring;
}

std::string FindShortestSuperstring(const std::vector<std::string>& data) {
    auto filteredData = FilterData(data);
    size_t size = filteredData.size();
    std::vector<std::vector<int>> overlaps(size, std::vector<int>(size));
    for (size_t i = 0; i < size; ++i) {
        for (size_t j = 0; j < size; ++j) {
            if (i != j) {
                overlaps[i][j] = MaxOverlap(filteredData[i], filteredData[j]);
            }
        }
    }
    std::vector<std::vector<int>> dp(1 << size, std::vector<int>(size));
    std::vector<std::vector<int>> parent(1 << size, std::vector<int>(size));
    for (size_t mask = 0; mask < static_cast<size_t>(1 << size); ++mask) {
        for (size_t last = 0; last < size; ++last) {
            if (mask & (1 << last)) {
                size_t pMask = mask ^ (1 << last);
                for (size_t preLast = 0; preLast < size; ++preLast) {
                    if ((pMask & (1 << preLast))
                        && (dp[pMask][preLast] + overlaps[preLast][last] >= dp[mask][last])) {
                        dp[mask][last] = dp[pMask][preLast] + overlaps[preLast][last];
                        parent[mask][last] = preLast;
                    }
                }
            } 
        }
    }
    std::string superstring = filteredData[0];
    for (size_t i = 1; i < size; ++i) {
        superstring.append(filteredData[i]);
    }
    for (size_t bit = 0; bit < size; ++bit) {
        std::vector<size_t> indexes;
        size_t currentMask = (1 << size) - 1, currentLastString = bit;
        for (size_t i = 0; i < size; ++i) {
            indexes.push_back(currentLastString);
            size_t pMask = currentMask ^ (1 << currentLastString);
            currentLastString = parent[currentMask][currentLastString];
            currentMask = pMask;
        }
        std::reverse(indexes.begin(), indexes.end());
        std::string currentSuperstring = GetStringByIndexes(filteredData, size, indexes, overlaps);
        if (currentSuperstring.length() < superstring.length()
            || (currentSuperstring.length() == superstring.length()
            && currentSuperstring < superstring)) {
            superstring = currentSuperstring;
        }
    }
    return superstring;
}



std::vector<std::string> ReadStrings(std::istream& in = std::cin) {
    size_t size;
    in >> size;
    std::vector<std::string> data(size);
    for (auto& elem : data) {
        in >> elem;
    }
    return data;
}

int main() {
    std::ios_base::sync_with_stdio(false);
    auto data = ReadStrings();
    std::cout << FindShortestSuperstring(data) << "\n";
    return 0;
}
