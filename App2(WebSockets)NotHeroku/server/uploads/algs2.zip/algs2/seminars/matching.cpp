#include <iostream>
#include <string>
#include <vector>

struct Cell {
    int64_t hvalue;
    int first_coordinate;
    int second_coordinate;
};

void PolynomialHashForRow(std::vector<int64_t>& hashes, const std::string& row,
    int row_number, int64_t& current_prime, int64_t initial_prime) {
    int64_t modulo = (1 << 61) - 1;
    // current_prime = p^(row_number * data[0].size())
    int size = row.size();
    hashes[row_number * size] = hashes[(row_number - 1) * size]
        + current_prime * static_cast<int64_t>(row[0]);
    hashes[row_number * size] %= modulo;
    for (int j = 1; j < size; ++j) {
        current_prime *= initial_prime;
        current_prime %= modulo;
        hashes[row_number * size + j] = (hashes[(row_number - 1) * size + j]
            + hashes[row_number * size + j - 1]) % modulo;
        hashes[row_number * size + j] += current_prime * static_cast<int64_t>(row[j]);
        hashes[row_number * size + j] %= modulo;
    }
}

std::vector<int64_t> PolynomialHashes(const std::vector<std::string>& data) {
    // data[i][j]
    // hashes[i * data[0].size() + j]; i = 0, data.size() - 1; j = 0, data[0].size() - 1
    // hashes[i][j] --> hash of matrix from (0, 0) to (i, j)
    auto appropriate_size = data.size() * data[0].size();
    std::vector<int64_t> hashes(appropriate_size);
    int64_t initial_prime = 31, current_prime = 1;
    for (int j = 0; j < static_cast<int>(data.size()); ++j) {
        PolynomialHashForRow(hashes, data[j], j, current_prime, initial_prime);
    }
    return hashes;
}

int64_t HashOfSubmatrix(const std::vector<int64_t>& hashes, int brow, int bcol, int prow,
    int pcol) {
    
}

std::vector<Cell> HashesOfSubmatries(const std::vector<std::string>& data, int prow, int pcol) {
    auto hashes_of_matrix = PolynomialHashes(data);
    std::vector<Cell> hashes((data.size() - prow + 1) * (data[0].size() - pcol + 1));
    for (int i = 0; i < data.size() - prow + 1; ++i) {
        for (int j = 0; j < data[0].size() - pcol + 1; ++j) {

        }
    }  
}