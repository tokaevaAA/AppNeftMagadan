#include <algorithm>
#include <iostream>
#include <iterator>
#include <string>
#include <vector>

std::vector<int> ZFunction(const std::vector<int>& buf) {
    int len = static_cast<int>(buf.size());
    std::vector<int> result(len);
    result[0] = len;
    for (int i = 1, left = 0, right = 0; i < len; ++i) {
        if (i <= right) {
            result[i] = std::min(right - i + 1, result[i - left]);
        }
        while (i + result[i] < len && buf[result[i]] == buf[i + result[i]]) {
            ++result[i];
        }
        if (i + result[i] - 1 > right) {
            left = i;
            right = i + result[i] - 1;
        }
    }
    return result;
}

template<typename T>
std::vector<T> GetPrefixFunction(size_t len, std::istream& in = std::cin) {
    std::vector<T> result(len);
    for (T& elem : result) {
        in >> elem;
    }
    return result;
}

std::vector<int> MakeStringFromPrefix(const std::vector<int>& prefixFunc) {
    size_t len = prefixFunc.size();
    std::vector<int> result(len);
    int max_number = 0;
    for (size_t i = 1; i < len; ++i) {
        if (prefixFunc[i] == 0) {
            result[i] = ++max_number;
        } else {
            result[i] = result[prefixFunc[i] - 1];
        }
    }
    return result;
}

std::vector<int> PToZ(const std::vector<int>& prefixFunc) {
    return ZFunction(MakeStringFromPrefix(prefixFunc));
}

int main() {
    std::ios_base::sync_with_stdio(false);
    size_t len;
    std::cin >> len;
    std::vector<int> preficFunc = GetPrefixFunction<int>(len);
    std::vector<int> zFunc = PToZ(preficFunc);
    std::copy(zFunc.begin(), zFunc.end(), std::ostream_iterator<int>(std::cout, " "));
    std::cout << "\n";
    return 0;
}
