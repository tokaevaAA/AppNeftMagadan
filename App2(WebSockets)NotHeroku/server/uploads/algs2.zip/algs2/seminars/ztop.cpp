#include <algorithm>
#include <iostream>
#include <iterator>
#include <vector>

template<typename T>
std::vector<T> GetZFunction(size_t len, std::istream& in = std::cin) {
    std::vector<T> result(len);
    for (T& elem : result) {
        in >> elem;
    }
    return result;
}

std::vector<int> ZToP(const std::vector<int>& zFunc) {
    int len = static_cast<int>(zFunc.size());
    std::vector<int> pFunc(len);
    for (int i = 1; i < len; ++i) {
        pFunc[i + zFunc[i] - 1] = std::max(pFunc[i + zFunc[i] - 1], zFunc[i]);
    }
    for (int i = len - 2; i >= 0; --i) {
        pFunc[i] = std::max(pFunc[i], pFunc[i + 1] - 1);
    }
    return pFunc;
}

int main() {
    std::ios_base::sync_with_stdio(false);
    size_t len;
    std::cin >> len;
    std::vector<int> zFunc = GetZFunction<int>(len);
    std::vector<int> pFunc = ZToP(zFunc);
    std::copy(pFunc.begin(), pFunc.end(), std::ostream_iterator<int>(std::cout, " "));
    std::cout << "\n";
    return 0;
}
