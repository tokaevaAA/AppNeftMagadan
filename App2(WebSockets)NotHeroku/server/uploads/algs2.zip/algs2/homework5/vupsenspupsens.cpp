#include <algorithm>
#include <iostream>
#include <iterator>
#include <vector>
#include <queue>

struct Edge {
    int src;
    int dest;
    int cap;
    int flow;
};

class Graph {
public:
    explicit Graph(int vertices_num) {
        adj_lists_.resize(vertices_num + 2);
        source_ = 0;
        sink_ = vertices_num + 1;
    }

    void AddEdge(int src, int dest, int capacity) {
        adj_lists_[src].push_back(edges_.size());
        edges_.push_back({src, dest, capacity, 0});
        adj_lists_[dest].push_back(edges_.size());
        edges_.push_back({dest, src, 0, 0});
    }

    std::vector<int> BFS() {
        std::vector<int> dist(adj_lists_.size(), -1);
        std::queue<int> order({source_});
        dist[source_] = 0;
        while (!order.empty()) {
            int curr_vertex = order.front();
            order.pop();
            for (int id : adj_lists_[curr_vertex]) {
                if (dist[edges_[id].dest] == -1 && edges_[id].cap - edges_[id].flow > 0) {
                    dist[edges_[id].dest] = dist[curr_vertex] + 1;
                    order.push(edges_[id].dest);
                }
            }
        }
        return dist;
    }

    int DFS(std::vector<int>& pointers, const std::vector<int>& dist,
        int start, int flow) {
        if (start == sink_ || flow == 0) {
            return flow;
        }
        while (static_cast<size_t>(pointers[start]) < adj_lists_[start].size()) {
            int id = adj_lists_[start][pointers[start]];
            int target = edges_[id].dest;
            if (dist[target] != dist[start] + 1) {
                ++pointers[start];
                continue;
            }
            int pushed = DFS(pointers, dist, target,
                std::min(edges_[id].cap - edges_[id].flow, flow));
            if (pushed > 0) {
                edges_[id].flow += pushed;
                edges_[id ^ 1].flow -= pushed;
                return pushed;
            }
            ++pointers[start];
        }
        return 0;
    }

    int Dinic() {
        for (auto& edge : edges_) {
            edge.flow = 0;
        }
        int answer = 0;
        std::vector<int> pointers(adj_lists_.size());
        std::vector<int> dist;
        do {
            pointers.assign(adj_lists_.size(), 0);
            dist = BFS();
            while (int pushed = DFS(pointers, dist, source_, inf_)) {
                answer += pushed;
            }
        } while (dist[sink_] != -1);
        return answer;
    }

private:
    std::vector<Edge> edges_;
    std::vector<std::vector<int>> adj_lists_;
    int source_, sink_;
    const double inf_ = 100000000;
};

Graph ReadGraph(std::istream& in = std::cin) {
    const int inf = 100000000;
    int vertices_num, edges_num;
    in >> vertices_num >> edges_num;
    Graph graph(vertices_num);
    std::vector<bool> types(vertices_num);
    for (int i = 0; i < vertices_num; ++i) {
        int marker, cost;
        in >> marker >> cost;
        if (marker == 1) {
            graph.AddEdge(i + 1, vertices_num + 1, cost);
        } else {
            graph.AddEdge(0, i + 1, cost);
        }
        types[i] = marker == 1;
    }
    for (int i = 0; i < edges_num; ++i) {
        int source, destination;
        in >> source >> destination;
        if (types[source - 1] == types[destination - 1]) {
            continue;
        }
        if (types[source - 1]) {
            graph.AddEdge(destination, source, inf);
        } else {
            graph.AddEdge(source, destination, inf);
        }
    }
    return graph;
}

int main() {
    std::ios_base::sync_with_stdio(false);
    Graph graph = ReadGraph();
    std::cout << graph.Dinic() << "\n";
    return 0;
}
