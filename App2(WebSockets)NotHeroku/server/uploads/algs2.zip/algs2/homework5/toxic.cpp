#include <algorithm>
#include <iostream>
#include <iterator>
#include <vector>
#include <queue>

struct Edge {
    int src;
    int dest;
    double cap;
    double flow;
};

class Graph {
public:
    explicit Graph(int vertices_num, int edges_num) {
        adj_lists_.resize(vertices_num + 2);
        source_ = 0;
        sink_ = vertices_num + 1;
        edges_num_ = edges_num;
    }

    void AddEdge(int src, int dest, double capacity, double inv_capacity = 0.) {
        adj_lists_[src].push_back(edges_.size());
        edges_.push_back({src, dest, capacity, 0});
        adj_lists_[dest].push_back(edges_.size());
        edges_.push_back({dest, src, inv_capacity, 0});
    }

    void ChangeCapacity(int edge_num, double difference) {
        edges_[edge_num].cap += difference;
    }

    std::vector<int> BFS() {
        std::vector<int> dist(adj_lists_.size(), -1);
        std::queue<int> order({source_});
        dist[source_] = 0;
        while (!order.empty()) {
            int curr_vertex = order.front();
            order.pop();
            for (int id : adj_lists_[curr_vertex]) {
                if (dist[edges_[id].dest] == -1 && edges_[id].cap - edges_[id].flow > 0) {
                    dist[edges_[id].dest] = dist[curr_vertex] + 1;
                    order.push(edges_[id].dest);
                }
            }
        }
        return dist;
    }

    void FindCut(std::vector<int>& cut, int start, std::vector<bool>& used) {
        used[start] = true;
        for (int id : adj_lists_[start]) {
            if (!used[edges_[id].dest] && edges_[id].cap - edges_[id].flow > 0) {
                FindCut(cut, edges_[id].dest, used);
            }
        }
        cut.push_back(start);
    }

    double DFS(std::vector<int>& pointers, const std::vector<int>& dist,
        int start, double flow) {
        if (start == sink_ || flow == 0) {
            return flow;
        }
        while (static_cast<size_t>(pointers[start]) < adj_lists_[start].size()) {
            int id = adj_lists_[start][pointers[start]];
            int target = edges_[id].dest;
            if (dist[target] != dist[start] + 1) {
                ++pointers[start];
                continue;
            }
            double pushed = DFS(pointers, dist, target,
                std::min(edges_[id].cap - edges_[id].flow, flow));
            if (pushed > 0) {
                edges_[id].flow += pushed;
                edges_[id ^ 1].flow -= pushed;
                return pushed;
            }
            ++pointers[start];
        }
        return 0;
    }

    double Dinic() {
        for (auto& edge : edges_) {
            edge.flow = 0.;
        }
        double answer = 0.;
        std::vector<int> pointers(adj_lists_.size());
        std::vector<int> dist;
        do {
            pointers.assign(adj_lists_.size(), 0);
            dist = BFS();
            while (double pushed = DFS(pointers, dist, source_, inf_)) {
                answer += pushed;
            }
        } while (dist[sink_] != -1);
        return answer;
    }

    int GetVerticesNum() const {
        return static_cast<int>(adj_lists_.size()) - 2;
    }

    int GetEdgesNum() const {
        return edges_num_;
    }

private:
    std::vector<Edge> edges_;
    std::vector<std::vector<int>> adj_lists_;
    int source_, sink_, edges_num_;
    const double inf_ = 100000000;
};

Graph ReadGraph(std::istream& in = std::cin) {
    int vertices_num, edges_num;
    in >> vertices_num >> edges_num;
    Graph graph(vertices_num, edges_num);
    std::vector<int> degrees(vertices_num);
    for (int i = 0; i < vertices_num; ++i) {
        graph.AddEdge(i + 1, vertices_num + 1, 0.);
    }
    for (int i = 0; i < edges_num; ++i) {
        int source, destination;
        in >> source >> destination;
        ++degrees[source - 1];
        ++degrees[destination - 1];
        graph.AddEdge(source, destination, 1., 1.);
    }
    for (int i = 0; i < vertices_num; ++i) {
        graph.AddEdge(0, i + 1, static_cast<double>(edges_num));
    }
    for (int i = 0; i < vertices_num; ++i) {
        graph.ChangeCapacity(i << 1,
        static_cast<double>(edges_num) - static_cast<double>(degrees[i]));
    }
    return graph;
}

void ChangeCapacities(Graph& graph, double eps) {
    for (int i = 0; i < graph.GetVerticesNum(); ++i) {
        graph.ChangeCapacity(i << 1, eps);
    }
}

std::vector<int> FindMaximumDensitySubgraph(Graph& graph) {
    int vertices_num = graph.GetVerticesNum();
    if (vertices_num == 1 || graph.GetEdgesNum() == 0) {
        return {1};
    }
    double left = 0., right = static_cast<double>(graph.GetEdgesNum());
    double eps = 1. / (vertices_num * (vertices_num - 1));
    double prev_guess = 0.;
    std::vector<bool> used(vertices_num, false);
    std::vector<int> current_cut = {0};
    while (right - left >= eps) {
        double guess = left + (right - left) / 2;
        ChangeCapacities(graph, 2 * (guess - prev_guess));
        prev_guess = guess;
        std::vector<int> cut;
        used.assign(vertices_num, false);
        graph.Dinic();
        graph.FindCut(cut, 0, used);
        if (cut.size() == 1) {
            right = guess;
        } else {
            left = guess;
            current_cut = cut;
        }
    }
    current_cut.pop_back();
    return current_cut;
}

void PrintAnswer(std::vector<int>& answer, std::ostream& out = std::cout) {
    out << answer.size() << "\n";
    std::sort(answer.begin(), answer.end());
    std::copy(answer.begin(), answer.end(), std::ostream_iterator<int>(std::cout, "\n"));
}

int main() {
    std::ios_base::sync_with_stdio(false);
    auto graph = ReadGraph();
    auto answer = FindMaximumDensitySubgraph(graph);
    PrintAnswer(answer);
    return 0;
}
