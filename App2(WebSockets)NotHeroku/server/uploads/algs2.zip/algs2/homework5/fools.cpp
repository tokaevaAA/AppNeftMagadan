#include <algorithm>
#include <iterator>
#include <iostream>
#include <vector>
#include <utility>
#include <string>
#include <map>
#include <queue>

struct Edge {
    int src;
    int dest;
    int cap;
    int flow;
};

class Graph {
public:
    explicit Graph(int vertices_num) {
        adj_lists_.resize(vertices_num);
        source_ = 0;
        sink_ = vertices_num - 1;
    }

    void AddEdge(int src, int dest, int capacity) {
        adj_lists_[src].push_back(edges_.size());
        edges_.push_back({src, dest, capacity, 0});
        adj_lists_[dest].push_back(edges_.size());
        edges_.push_back({dest, src, 0, 0});
    }

    void ChangeCapacity(int edge_num, int new_capacity) {
        edges_[edge_num].cap = new_capacity;
    }

    std::vector<int> BFS() {
        std::vector<int> dist(adj_lists_.size(), -1);
        std::queue<int> order({source_});
        dist[source_] = 0;
        while (!order.empty()) {
            int curr_vertex = order.front();
            order.pop();
            for (int id : adj_lists_[curr_vertex]) {
                if (dist[edges_[id].dest] == -1 && edges_[id].cap - edges_[id].flow > 0) {
                    dist[edges_[id].dest] = dist[curr_vertex] + 1;
                    order.push(edges_[id].dest);
                }
            }
        }
        return dist;
    }

    int DFS(std::vector<int>& pointers, const std::vector<int>& dist,
        int start, int flow) {
        if (start == sink_ || flow == 0) {
            return flow;
        }
        while (static_cast<size_t>(pointers[start]) < adj_lists_[start].size()) {
            int id = adj_lists_[start][pointers[start]];
            int target = edges_[id].dest;
            if (dist[target] != dist[start] + 1) {
                ++pointers[start];
                continue;
            }
            int pushed = DFS(pointers, dist, target,
                std::min(edges_[id].cap - edges_[id].flow, flow));
            if (pushed > 0) {
                edges_[id].flow += pushed;
                edges_[id ^ 1].flow -= pushed;
                return pushed;
            }
            ++pointers[start];
        }
        return 0;
    }

    int Dinic() {
        for (auto& edge : edges_) {
            edge.flow = 0;
        }
        int answer = 0;
        std::vector<int> pointers(adj_lists_.size());
        bool enough = false;
        while (!enough) {
            pointers.assign(adj_lists_.size(), 0);
            auto dist = BFS();
            if (dist[sink_] == -1) {
                enough = true;
                return answer;
            }
            while (int pushed = DFS(pointers, dist, source_, inf_)) {
                answer += pushed;
            }
        }
        return answer;
    }

private:
    std::vector<Edge> edges_;
    std::vector<std::vector<int>> adj_lists_;
    int source_, sink_;
    const int inf_ = 100000000;
};

template <class Func>
int FillMaps(std::map<std::string, int>& hasher,
    const std::vector<std::pair<std::string, std::string>>& data, Func getter) {
    int current_number = 0;
    for (const auto& record : data) {
        if (hasher.find(getter(record)) == hasher.end()) {
            hasher[getter(record)] = current_number;
            ++current_number;
        }
    }
    // returns total number of unique words
    return current_number;
}

std::string GetFirst(const std::pair<std::string, std::string>& record) {
    return record.first;
}

std::string GetSecond(const std::pair<std::string, std::string>& record) {
    return record.second;
}

int SolveOneCase(const std::vector<std::pair<std::string, std::string>>& records) {
    std::map<std::string, int> hasher_left, hasher_right;
    int size_left = FillMaps(hasher_left, records, GetFirst);
    int size_right = FillMaps(hasher_right, records, GetSecond);
    Graph graph(size_left + size_right + 2);
    for (const auto& record : records) {
        graph.AddEdge(hasher_left[record.first] + 1,
            hasher_right[record.second] + 1 + size_left, 1);
    }
    for (int i = 0; i < size_left; ++i) {
        graph.AddEdge(0, i + 1, 1);
    }
    for (int i = 0; i < size_right; ++i) {
        graph.AddEdge(size_left + 1 + i, size_left + size_right + 1, 1);
    }
    return static_cast<int>(records.size()) - size_left - size_right + graph.Dinic();
}

std::vector<std::pair<std::string, std::string>> ReadPairs(std::istream& in = std::cin) {
    size_t size;
    in >> size;
    std::vector<std::pair<std::string, std::string>> result(size);
    for (auto& record : result) {
        in >> record.first >> record.second;
    }
    return result;
}

std::vector<int> Solve(int tests_num) {
    std::vector<int> answer;
    for (int i = 0; i < tests_num; ++i) {
        answer.push_back(SolveOneCase(ReadPairs()));
    }
    return answer;
}

void PrintAnswer(const std::vector<int>& answer, std::ostream& out = std::cout) {
    for (size_t i = 0; i < answer.size(); ++i) {
        out << "Case #" << i + 1 << ": " << answer[i] << "\n";
    }
}

int main() {
    int tests_num;
    std::cin >> tests_num;
    auto answer = Solve(tests_num);
    PrintAnswer(answer);
    return 0;
}
