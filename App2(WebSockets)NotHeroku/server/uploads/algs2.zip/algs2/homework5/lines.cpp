#include <algorithm>
#include <utility>
#include <iostream>
#include <vector>
#include <iterator>
#include <map>
#include <queue>

struct Rational {
    // denumenator > 0
    Rational(int64_t enumenator_, int64_t denumenator_, int idx_ = -1) {
        if (denumenator_ > 0) {
            enumenator = enumenator_;
            denumenator = denumenator_;
        } else {
            enumenator = -enumenator_;
            denumenator = -denumenator_;
        }
        idx = idx_;
    }
    int64_t enumenator;
    int64_t denumenator;
    int idx = -1;
    bool operator==(const Rational& elem) {
        return enumenator * elem.denumenator == denumenator * elem.enumenator;
    }
    friend bool operator<(const Rational& fst, const Rational& snd) {
        return fst.enumenator * snd.denumenator < fst.denumenator * snd.enumenator;
    }
    void Print() {
        std::cout << enumenator << "/" << denumenator << std::endl;
    }
};

std::map<Rational, int> Biection(const std::vector<Rational>& numbers) {
    std::map<Rational, int> biection;
    int current_number = 0;
    for (const auto& number : numbers) {
        if (biection.find(number) == biection.end()) {
            biection[number] = current_number++;
        }
    }
    return biection;
}

struct Edge {
    int src;
    int dest;
    int cap;
    int flow;
    int line_id;
};

class Graph {
public:
    explicit Graph(int size_slopes, int size_intercepts) {
        adj_lists_.resize(size_intercepts + size_slopes + 2);
        source_ = 0;
        sink_ = size_intercepts + size_slopes + 1;
        size_slopes_ = size_slopes;
        size_intercepts_ = size_intercepts_;
    }

    void AddEdge(int src, int dest, int capacity, int line_id = -1) {
        adj_lists_[src].push_back(edges_.size());
        edges_.push_back({src, dest, capacity, 0, line_id});
        adj_lists_[dest].push_back(edges_.size());
        edges_.push_back({dest, src, 0, 0, line_id});
    }

    std::vector<int> BFS() {
        std::vector<int> dist(adj_lists_.size(), -1);
        std::queue<int> order({source_});
        dist[source_] = 0;
        while (!order.empty()) {
            int curr_vertex = order.front();
            order.pop();
            for (int id : adj_lists_[curr_vertex]) {
                if (dist[edges_[id].dest] == -1 && edges_[id].cap - edges_[id].flow > 0) {
                    dist[edges_[id].dest] = dist[curr_vertex] + 1;
                    order.push(edges_[id].dest);
                }
            }
        }
        return dist;
    }

    int DFS(std::vector<int>& pointers, const std::vector<int>& dist,
        int start, int flow) {
        if (start == sink_ || flow == 0) {
            return flow;
        }
        while (static_cast<size_t>(pointers[start]) < adj_lists_[start].size()) {
            int id = adj_lists_[start][pointers[start]];
            int target = edges_[id].dest;
            if (dist[target] != dist[start] + 1) {
                ++pointers[start];
                continue;
            }
            int pushed = DFS(pointers, dist, target,
                std::min(edges_[id].cap - edges_[id].flow, flow));
            if (pushed > 0) {
                edges_[id].flow += pushed;
                edges_[id ^ 1].flow -= pushed;
                return pushed;
            }
            ++pointers[start];
        }
        return 0;
    }

    int Dinic() {
        for (auto& edge : edges_) {
            edge.flow = 0;
        }
        int answer = 0;
        std::vector<int> pointers(adj_lists_.size());
        std::vector<int> dist;
        do {
            pointers.assign(adj_lists_.size(), 0);
            dist = BFS();
            while (int pushed = DFS(pointers, dist, source_, inf_)) {
                answer += pushed;
            }
        } while (dist[sink_] != -1);
        return answer;
    }

    std::vector<int> GetIndexesOfLinesMatching() {
        std::vector<int> answer;
        for (int i = 1; i < size_slopes_ + 1; ++i) {
            for (int edge_id : adj_lists_[i]) {
                if (edges_[edge_id].cap == 1 && edges_[edge_id].flow == 1) {
                    answer.push_back(edges_[edge_id].line_id + 1);
                }
            }
        }
        return answer;
    }

private:
    std::vector<Edge> edges_;
    std::vector<std::vector<int>> adj_lists_;
    int source_, sink_;
    int size_slopes_, size_intercepts_;
    const int inf_ = 100000000;
};

Graph MakeGraph(const std::vector<Rational>& slopes, const std::vector<Rational>& intercepts) {
    // no vertical lines here
    auto hasher_slopes = Biection(slopes), hasher_intercepts = Biection(intercepts);
    int size_slopes = static_cast<int>(hasher_slopes.size());
    int size_intercepts = static_cast<int>(hasher_intercepts.size());
    Graph graph(size_slopes, size_intercepts);
    for (int i = 0; i < size_slopes; ++i) {
        graph.AddEdge(0, i + 1, 1);
    }
    for (size_t i = 0; i < slopes.size(); ++i) {
        graph.AddEdge(hasher_slopes[slopes[i]] + 1,
            hasher_intercepts[intercepts[i]] + 1 + size_slopes, 1, slopes[i].idx);
    }
    for (int i = 0; i < size_intercepts; ++i) {
        graph.AddEdge(i + 1 + size_slopes, size_intercepts + size_slopes + 1, 1);
    }
    return graph;
}

struct Data {
    std::vector<Rational> slopes;
    std::vector<Rational> intercepts;
    int number_of_vertical_lines;
    int num_of_first_non_zero_intercept_vertical_line;
};

std::vector<int> SolveCase(const Data& data) {
    // slopes and intercepts are for non-vertical lines
    if (data.slopes.empty()) {
        // only vertical lines, at least one line - that is an answer
        return {1};
    }
    Graph graph = MakeGraph(data.slopes, data.intercepts);
    graph.Dinic();
    auto answer = graph.GetIndexesOfLinesMatching();
    // at least one non-vertical line
    if (!data.number_of_vertical_lines) {
        // no vertical lines
        return answer;
    }
    // at least one vertical line and non-vertical line
    if (data.num_of_first_non_zero_intercept_vertical_line != -1) {
        // optimal one is here
        answer.push_back(data.num_of_first_non_zero_intercept_vertical_line + 1);
        return answer;
    }
    // at least one non-vertical line, vertical lines are only x = 0
    return answer;
}

struct Triple {
    int64_t first;
    int64_t second;
    int64_t third;
    Triple(int64_t fst, int64_t snd, int64_t thd) {
        first = fst;
        second = snd;
        third = thd;
    }
    bool operator==(const Triple& elem) {
        return Rational(first, second) == Rational(elem.first, elem.second)
            && Rational(third, second) == Rational(elem.third, elem.second);
    }
    friend bool operator<(const Triple& fst, const Triple& snd) {
        return fst.first < snd.first;
    }
    friend bool operator==(const Triple& fst, const Triple& snd) {
        return Rational(fst.first, fst.second) == Rational(snd.first, snd.second)
            && Rational(fst.third, fst.second) == Rational(snd.third, snd.second);
    }
};

bool Find(const std::vector<Triple>& uniques, const Triple& elem) {
    for (const auto& triple : uniques) {
        if (triple == elem) {
            return true;
        }
    }
    return false;
}

Data GetData(std::istream& in = std::cin) {
    int num_of_first_non_zero_intercept_vertical_line = -1;
    int number_of_vertical_lines = 0;
    int size;
    in >> size;
    std::vector<Rational> slopes, intercepts;
    std::vector<Triple> uniques;
    for (int idx = 0; idx < size; ++idx) {
        int64_t first, second, third;
        in >> first >> second >> third;
        if (second == 0) {
            ++number_of_vertical_lines;
            if (third != 0 && num_of_first_non_zero_intercept_vertical_line == -1) {
                num_of_first_non_zero_intercept_vertical_line = idx;
            }
        } else {
            if (!Find(uniques, Triple(first, second, third))) {
                slopes.push_back({-first, second, idx});
                intercepts.push_back({-third, second, idx});
                uniques.push_back(Triple(first, second, third));
            }
        }
    }
    return {slopes, intercepts, number_of_vertical_lines,
        num_of_first_non_zero_intercept_vertical_line};
}

std::vector<std::vector<int>> Solve(int test_cases) {
    std::vector<std::vector<int>> answer;
    for (int test = 0; test < test_cases; ++test) {
        auto data = GetData();
        answer.push_back(SolveCase(data));
    }
    return answer;
}

void PrintAnswer(const std::vector<std::vector<int>>& answer, std::ostream& out = std::cout) {
    for (const auto& indices : answer) {
        out << indices.size() << "\n";
        std::copy(indices.begin(), indices.end(), std::ostream_iterator<int>(out, "\n"));
    }
}

int main() {
    std::ios_base::sync_with_stdio(false);
    int test_cases;
    std::cin >> test_cases;
    auto answer = Solve(test_cases);
    PrintAnswer(answer);
    return 0;
}
