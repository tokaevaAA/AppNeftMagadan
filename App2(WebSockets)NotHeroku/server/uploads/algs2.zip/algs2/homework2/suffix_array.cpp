#include <algorithm>
#include <iostream>
#include <string>
#include <vector>

struct Digits {
    size_t left;
    size_t right;
    size_t suff_idx;
    bool operator<(const Digits& digit) {
        return (this->left < digit.left)
        || (this->left == digit.left && this->right < digit.right);
    }
};

std::vector<Digits> GetDigits(const std::vector<size_t>& labels, size_t prevStep) {
    std::vector<Digits> digits;
    for (size_t i = 0; i < labels.size(); ++i) {
        if (i + prevStep < labels.size()) {
            digits.push_back({labels[i], labels[i + prevStep], i});
        } else {
            digits.push_back({labels[i], 0, i});
        }
    }
    return digits;
}

std::vector<size_t> GetLabels(const std::vector<size_t>& prevLabels, size_t prevStep,
                              const std::string& text) {
    std::vector<Digits> digits = GetDigits(prevLabels, prevStep);
    std::sort(digits.begin(), digits.end());
    std::vector<size_t> labels(prevLabels.size());
    size_t curr_label = 1;
    for (size_t i = 0; i < digits.size() - 1; ++i) {
        labels[digits[i].suff_idx] = curr_label;
        if (digits[i] < digits[i + 1]) {
            ++curr_label;
        }
    }
    labels[digits[digits.size() - 1].suff_idx] = curr_label;
    return labels;
}

std::vector<size_t> LabelsOne(const std::string& text) {
    std::vector<std::vector<size_t>> range(300);
    for (size_t i = 0; i < text.size(); ++i) {
        range[static_cast<size_t>(text[i])].push_back(i);
    }
    std::vector<size_t> sorted;
    std::vector<size_t> labels(text.size());
    for (auto& elem : range) {
        for (auto& letter : elem) {
            sorted.push_back(letter);
        }
    }
    size_t curr_label = 1;
    for (size_t i = 0; i < text.size() - 1; ++i) {
        labels[sorted[i]] = curr_label;
        if (text[sorted[i]] < text[sorted[i + 1]]) {
            ++curr_label;
        }
    }
    labels[sorted[text.size() - 1]] = curr_label;
    return labels;
}

std::vector<size_t> SuffixArray(const std::string& text) {
    auto prev_labels = LabelsOne(text);
    size_t step = 1;
    while (step < text.size()) {
        prev_labels = GetLabels(prev_labels, step, text);
        step <<= 1;
    }
    std::vector<Digits> digits = GetDigits(prev_labels, step);
    std::sort(digits.begin(), digits.end());
    std::vector<size_t> suffArray;
    for (auto& digit : digits) {
        suffArray.push_back(digit.suff_idx);
    }
    return suffArray;
}

std::string BWT(const std::string& text) {
    auto sa = SuffixArray(text + text);
    std::string result;
    for (size_t i = 0; i < text.size() << 1; ++i) {
        if (sa[i] < text.size()) {
            if (sa[i] == 0) {
                result.push_back(text[text.size() - 1]);
            } else {
                result.push_back(text[sa[i] - 1]);
            }
        }
    }
    return result;
}

int main() {
    std::ios_base::sync_with_stdio(false);
    std::string text;
    std::cin >> text;
    std::cout << BWT(text) << std::endl;
    return 0;
}
