#include <algorithm>
#include <iostream>
#include <iterator>
#include <string>
#include <vector>

struct Digits {
    size_t left;
    size_t right;
    size_t suff_idx;
    bool operator<(const Digits& digit) {
        return (this->left < digit.left)
        || (this->left == digit.left && this->right < digit.right);
    }
};

std::vector<Digits> GetDigits(const std::vector<size_t>& labels, size_t prevStep) {
    std::vector<Digits> digits;
    for (size_t i = 0; i < labels.size(); ++i) {
        if (i + prevStep < labels.size()) {
            digits.push_back({labels[i], labels[i + prevStep], i});
        } else {
            digits.push_back({labels[i], 0, i});
        }
    }
    return digits;
}

std::vector<size_t> GetLabels(const std::vector<size_t>& prevLabels, size_t prevStep,
                              const std::string& text) {
    std::vector<Digits> digits = GetDigits(prevLabels, prevStep);
    std::sort(digits.begin(), digits.end());
    std::vector<size_t> labels(prevLabels.size());
    size_t curr_label = 1;
    for (size_t i = 0; i < digits.size() - 1; ++i) {
        labels[digits[i].suff_idx] = curr_label;
        if (digits[i] < digits[i + 1]) {
            ++curr_label;
        }
    }
    labels[digits[digits.size() - 1].suff_idx] = curr_label;
    return labels;
}

std::vector<size_t> LabelsOne(const std::string& text) {
    std::vector<std::vector<size_t>> range(300);
    for (size_t i = 0; i < text.size(); ++i) {
        range[static_cast<size_t>(text[i])].push_back(i);
    }
    std::vector<size_t> sorted;
    std::vector<size_t> labels(text.size());
    for (auto& elem : range) {
        for (auto& letter : elem) {
            sorted.push_back(letter);
        }
    }
    size_t curr_label = 1;
    for (size_t i = 0; i < text.size() - 1; ++i) {
        labels[sorted[i]] = curr_label;
        if (text[sorted[i]] < text[sorted[i + 1]]) {
            ++curr_label;
        }
    }
    labels[sorted[text.size() - 1]] = curr_label;
    return labels;
}

std::vector<size_t> SuffixArray(const std::string& text) {
    auto prev_labels = LabelsOne(text);
    size_t step = 1;
    while (step < text.size()) {
        prev_labels = GetLabels(prev_labels, step, text);
        step <<= 1;
    }
    std::vector<Digits> digits = GetDigits(prev_labels, step);
    std::sort(digits.begin(), digits.end());
    std::vector<size_t> suffArray;
    for (auto& digit : digits) {
        suffArray.push_back(digit.suff_idx);
    }
    return suffArray;
}

std::vector<size_t> Rank(const std::vector<size_t>& suffArray) {
    std::vector<size_t> rank(suffArray.size());
    for (size_t i = 0; i < suffArray.size(); ++i) {
        rank[suffArray[i]] = i;
    }
    return rank;
}

void LCPPart(const std::string& text, const std::vector<size_t>& suffArray,
             const std::vector<size_t>& rankArray, size_t left, size_t right,
             std::vector<size_t>& lcpArray) {
    size_t prevBord = 0;
    for (size_t idx = left; idx < right; ++idx) {
        size_t ptr_fst = idx, ptr_snd = suffArray[rankArray[idx] + 1];
        size_t lcp = 0, pos = prevBord;
        while (ptr_fst + pos < text.size() && ptr_snd + pos < text.size()
        && text[ptr_fst + pos] == text[ptr_snd + pos]) {
            ++lcp;
            ++pos;
        }
        lcpArray[idx] = lcp + prevBord;
        if (lcp + prevBord > 0) {
            prevBord = lcp + prevBord - 1;
        } else {
            prevBord = 0;
        }
    }
}

std::vector<size_t> LCP(const std::string& text) {
    auto suffArray = SuffixArray(text);
    auto rankArray = Rank(suffArray);
    std::vector<size_t> lcpArray(text.size());
    LCPPart(text, suffArray, rankArray, 0, suffArray[text.size() - 1], lcpArray);
    LCPPart(text, suffArray, rankArray, suffArray[text.size() - 1] + 1, text.size(), lcpArray);
    std::vector<size_t> lcpFinal(text.size() - 1);
    for (size_t i = 0; i < text.size() - 1; ++i) {
        lcpFinal[i] = lcpArray[suffArray[i]];
    }
    return lcpFinal;
}

size_t NumberOfDistinctSubstrings(const std::string& text) {
    auto suffArray = SuffixArray(text);
    auto lcpArray = LCP(text);
    size_t answer = text.size() - suffArray[0];
    for (size_t i = 0; i < text.size() - 1; ++i) {
        answer += text.size() - suffArray[i + 1] - lcpArray[i];
    }
    return answer;
}

int main() {
    std::ios_base::sync_with_stdio(false);
    std::string text;
    std::cin >> text;
    std::cout << NumberOfDistinctSubstrings(text) << std::endl;
    return 0;
}
