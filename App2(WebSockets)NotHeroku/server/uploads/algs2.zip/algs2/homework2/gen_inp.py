import random
import string

size = 5000

def randomString(stringLength=5):
    """Generate a random string of fixed length """
    letters = string.ascii_lowercase
    return [''.join(random.choice(letters) for i in range(stringLength)) for i in range(size)]
    return ''.join('a' for i in range(stringLength))

print(size)
data = randomString()
for word in data:
    print(word)

queries = randomString()
print(size)
for word in queries:
    print(word)