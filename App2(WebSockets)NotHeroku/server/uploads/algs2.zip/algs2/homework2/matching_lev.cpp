#include <algorithm>
#include <cassert>
#include <iostream>
#include <iterator>
#include <map>
#include <unordered_set>
#include <unordered_map>
#include <string>
#include <vector>
#include <numeric>
#include <cmath>

int LevDist(const char* first, const char* second, int lenF, int lenS) {
    static int col[19];
    std::iota(col, col + lenS + 1, 0);
    for (int numCol = 0; numCol < lenF; ++numCol) {
        int fst = col[0], snd = std::min(col[1], numCol + 1);
        col[0] = numCol + 1;
        for (int i = 1; i < lenS; ++i) {
            int val = std::min(fst + (second[i - 1] != first[numCol]),
                snd + 1);
            fst = col[i];
            snd = std::min(col[i + 1], val);
            col[i] = val;
        }
        col[lenS] = std::min(fst + (second[lenS - 1] != first[numCol]),
            snd + 1);
    }
    return col[lenS];
}

class TreeNode {
    public:
    explicit TreeNode(const std::string& word_) {
        for (size_t i = 0; i < 19; ++i) {
            children[i] = nullptr;
        }
        word = word_;
    }
    TreeNode* children[19];
    std::string word;
};

void DeleteTree(TreeNode* root) {
    if (!root) {
        return;
    }
    for (size_t i = 0; i < 19; ++i) {
        DeleteTree(root->children[i]);
    }
    delete root;
}

void AddString(TreeNode* root, const std::string& word) {
    if (root->word == word) {
        return;
    }
    int dist = LevDist(word.c_str(), root->word.c_str(), word.size(), root->word.size());
    if (root->children[dist]) {
        AddString(root->children[dist], word);
    } else {
        root->children[dist] = new TreeNode(word);
    }
}

void Search(TreeNode* root, const std::string& word,
    std::string& cand, int& len) {
    if (len == 1) {
        return;
    }
    int dist = LevDist(word.c_str(), root->word.c_str(), word.size(), root->word.size());
    if ((dist < len) || (len == -1 && dist <= 2)) {
        cand = root->word;
        len = dist;
    }
    if (root->children[dist]) {
        Search(root->children[dist], word, cand, len);
    }
    if (dist >= 1 && dist < 19 && root->children[dist - 1]) {
        Search(root->children[dist - 1], word, cand, len);
    }
    if (dist + 1 >= 0 && dist + 1 < 19 && root->children[dist + 1]) {
        Search(root->children[dist + 1], word, cand, len);
    }
    if (dist - 2 >= 0 && dist - 2 < 19 && root->children[dist - 2]) {
        Search(root->children[dist - 2], word, cand, len);
    }
    if (dist + 2 >= 0 && dist + 2 < 19 && root->children[dist + 2]) {
        Search(root->children[dist + 2], word, cand, len);
    }
}

std::vector<std::string> ProcessQueries(const std::vector<std::string>& queries,
    TreeNode* root, std::unordered_set<std::string>& words) {
    std::vector<std::string> answers;
    for (const auto& query : queries) {
        if (query.size() >= 18) {
            answers.push_back("-1");
        } else if (words.find(query) != words.end()) {
            answers.push_back(query);
        } else {
            std::string cand;
            int len = -1;
            Search(root, query, cand, len);
            if (len > 0) {
                answers.push_back(cand);
            } else {
                answers.push_back("-1");
            }
        }
    }
    DeleteTree(root);
    return answers;
}


std::vector<std::string> Solve(std::vector<std::string>& words,
    const std::vector<std::string>& queries) {
    std::sort(words.begin(), words.end());
    TreeNode *root = new TreeNode(words[0]);
    std::unordered_set<std::string> words_cache;
    for (const auto& word : words) {
        AddString(root, word);
        words_cache.insert(word);
    }
    return ProcessQueries(queries, root, words_cache);
}

std::vector<std::string> GetWords(std::istream& in = std::cin) {
    size_t size;
    in >> size;
    std::vector<std::string> words(size);
    for (auto& word : words) {
        in >> word;
    }
    return words;
}

int main() {
    std::ios_base::sync_with_stdio(false);
    auto words = GetWords();
    auto queries = GetWords();
    auto answers = Solve(words, queries);
    std::copy(answers.begin(), answers.end(), std::ostream_iterator<std::string>(std::cout, "\n"));
    return 0;
}
