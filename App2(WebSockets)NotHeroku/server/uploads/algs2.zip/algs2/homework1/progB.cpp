#include <iostream>
#include <string>
#include <vector>
#include <queue>

struct Node {
    bool isTerminal = false;
    Node* next[26];
    Node* prefixFunc = nullptr;
    Node* terminalLink = nullptr;
    Node* parent = nullptr;
};

void AddString(const std::string& pattern, Node* root) {
    Node* current = root;
    for (const char& letter : pattern) {
        size_t destination = static_cast<size_t>(letter) - 'a';
        if (!current -> next[destination]) {
            current -> next[destination] = new Node;
        }
        current = current -> next[destination];
    }
    current -> isTerminal = true;
}

void DeleteTrie(Node* root) {
    if (!root) {
        return;
    }
    for (size_t i = 0; i < 26; ++i) {
        DeleteTrie(root -> next[i]);
    }
    delete root;
}

int main() {
    return 0;
}
