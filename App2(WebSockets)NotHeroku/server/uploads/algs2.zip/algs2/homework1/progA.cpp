#include <algorithm>
#include <iostream>
#include <iterator>
#include <string>
#include <vector>

std::string Unite(std::string& pattern, std::string& text) {
    std::string result;
    result.append(pattern);
    result.append("$");
    result.append(text);
    return result;
}

std::string UniteInverse(std::string& pattern, std::string& text) {
    std::string result;
    std::reverse(pattern.begin(), pattern.end());
    std::reverse(text.begin(), text.end());
    result.append(pattern);
    result.append("$");
    result.append(text);
    return result;
}

std::vector<int> ZFunction(const std::string& buf) {
    int len = static_cast<int>(buf.length());
    std::vector<int> result(len);
    for (int i = 1, left = 0, right = 0; i < len; ++i) {
        if (i <= right) {
            result[i] = std::min(right - i + 1, result[i - left]);
        }
        while (i + result[i] < len && buf[result[i]] == buf[i + result[i]]) {
            ++result[i];
        }
        if (i + result[i] - 1 > right) {
            left = i;
            right = i + result[i] - 1;
        }
    }
    return result;
}

std::vector<int> Solve(std::string& pattern, std::string& text) {
    size_t pLen = pattern.length(), tLen = text.length();
    if (tLen < pLen) {
        return {};
    }
    std::vector<int> answer;
    std::string unite = Unite(pattern, text), uniteInv = UniteInverse(pattern, text);
    pattern.clear();
    text.clear();
    std::vector<int> zFunc = ZFunction(unite);
    std::vector<int> zFuncInv = ZFunction(uniteInv);
    for (size_t i = 0; i < tLen - pLen + 1; ++i) {
        if (zFunc[i + pLen + 1] == static_cast<int>(pLen)
            || zFunc[i + pLen + 1] + zFuncInv[tLen - i + 1] + 1 == static_cast<int>(pLen)) {
            answer.push_back(i + 1);
        }
    }
    return answer;
}

void PrintAnswer(const std::vector<int>& answer, std::ostream& out = std::cout) {
    out << answer.size() << "\n";
    if (answer.empty()) {
        return;
    }
    std::copy(answer.begin(), answer.end(), std::ostream_iterator<int>(out, " "));
    out << "\n";
}

int main() {
    std::ios_base::sync_with_stdio(false);
    std::string pattern, text;
    std::cin >> pattern >> text;
    std::vector<int> answer = Solve(pattern, text);
    PrintAnswer(answer);
    return 0;
}
