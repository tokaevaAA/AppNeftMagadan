#include <iostream>
#include <vector>
#include <string>

size_t FindK(const std::string& text) {
    size_t answer = 1;
    size_t len = text.length();
    for (size_t subst_size = 1; subst_size <= len; ++subst_size) {
        size_t current_value = 1;
        for (size_t i = 1; i < len; ++i) {
            if (i < subst_size || text[i] == text[i - subst_size]) {
                ++current_value;
            } else {
                current_value = subst_size;
            }
            if (current_value % subst_size == 0 && current_value / subst_size > answer) {
                answer = current_value / subst_size;
            }
        }
    }
    return answer;
}

int main() {
    std::ios_base::sync_with_stdio(false);
    std::string text;
    std::cin >> text;
    std::cout << FindK(text) << "\n";
    return 0;
}
