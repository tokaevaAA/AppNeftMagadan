import random

n, k = 16, 100
print(n, k)
for i in range(n):
    print(random.randint(1, 15))

for i in range(k):
    count = random.randint(0, 1000 * n)
    vec = [random.randint(1, n) for i in range(count)]
    vec = set(vec)
    print(len(vec))
    print(*list(vec))
