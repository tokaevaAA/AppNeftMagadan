#include <algorithm>
#include <iostream>
#include <iterator>
#include <vector>

struct Node {
    int left, right, value;
    explicit Node(int left_, int right_, int value_)
        : left(left_), right(right_), value(value_) {}
};

class PersistentSegmentTree {
public:
    PersistentSegmentTree() {
        roots_.push_back(AddNode(0, terminal_, terminal_));
    }
    int AddNode(int value, int left, int right) {
        container_.emplace_back(Node(left, right, value));
        return container_.size() - 1;
    };
    int GetValue(int node) {
        if (node == terminal_) {
            return 0;
        }
        return container_[node].value;
    }
    int GetLeft(int node) {
        if (node == terminal_) {
            return terminal_;
        }
        return container_[node].left;
    }
    int GetRight(int node) {
        if (node == terminal_) {
            return terminal_;
        }
        return container_[node].right;
    }
    int ChangeOnSegment(int node, int index, int left_bord, int right_bord) {
        if (node == terminal_) {
            if (left_bord == right_bord) {
                int value = AddNode(1, terminal_, terminal_);
                return value;
            }
            node = AddNode(0, terminal_, terminal_);
        }
        if (left_bord == right_bord) {
            return AddNode(container_[node].value + 1, terminal_, terminal_);
        }
        int new_node = AddNode(0, container_[node].left, container_[node].right);
        int middle = left_bord + (right_bord - left_bord) / 2;
        if (index <= middle) {
            int value = ChangeOnSegment(container_[node].left, index,
                left_bord, middle);
            container_[new_node].left = value;
        } else {
            int value = ChangeOnSegment(container_[node].right, index,
                middle + 1, right_bord);
            container_[new_node].right = value;
        }
        container_[new_node].value = GetValue(container_[new_node].left)
            + GetValue(container_[new_node].right);
        return new_node;
    }
    void Change(int index) {
        roots_.push_back(ChangeOnSegment(roots_.back(), index, left_bound_, right_bound_));
    }
    int RecursiveQuery(int first, int second, int order, int left_bord, int right_bord) {
        if (left_bord == right_bord) {
            return left_bord;
        }
        int middle = left_bord + (right_bord - left_bord) / 2;
        int number_of_lows = GetValue(GetLeft(second)) - GetValue(GetLeft(first));
        if (order <= number_of_lows) {
            return RecursiveQuery(GetLeft(first), GetLeft(second),
                order, left_bord, middle);
        }
        return RecursiveQuery(GetRight(first), GetRight(second), order - number_of_lows,
            middle + 1, right_bord);
    }
    int KthStatistics(int left, int right, int order) {
        return RecursiveQuery(roots_[left - 1], roots_[right], order, left_bound_, right_bound_);
    }
    void BuildForArray(const std::vector<int>& arr) {
        for (const int elem : arr) {
            Change(elem);
        }
    }

private:
    std::vector<int> roots_;
    std::vector<Node> container_;
    const int terminal_ = -1, left_bound_ = -1e9, right_bound_ = 1e9;
};

struct Query {
    int left, right, order;
};

struct Input {
    std::vector<int> arr;
    std::vector<Query> queries;
};

void FindSumOfStatistics(const Input& input) {
    PersistentSegmentTree tree;
    tree.BuildForArray(input.arr);
    for (const auto& query : input.queries) {
        std::cout << tree.KthStatistics(query.left, query.right, query.order) << "\n";
    }
}

Input Get() {
    int elems_count, queries_count;
    std::cin >> elems_count >> queries_count;
    std::vector<int> arr(elems_count);
    for (int& elem : arr) {
        std::cin >> elem;
    }
    std::vector<Query> queries(queries_count);
    for (auto& query : queries) {
        std::cin >> query.left >> query.right >> query.order;
    }
    return {arr, queries};
}

int main() {
    std::ios_base::sync_with_stdio(false);
    auto input = Get();
    FindSumOfStatistics(input);
    return 0;
}
