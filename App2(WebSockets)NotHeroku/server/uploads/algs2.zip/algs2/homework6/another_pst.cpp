#include <iostream>
#include <vector>

struct Node {
    Node *left, *right;
    int value;
    Node(Node* left_, Node* right_, int value_) {
        left = left_;
        right = right_;
        value = value_;
    }
};

class PersistentSegmentTree {
public:
    PersistentSegmentTree(int versions_num) {
        roots_.resize(versions_num + 1);
        roots_[0] = CreateNode();
    }
    Node* CreateNode(int value = 0, Node* left = nullptr,
        Node* right = nullptr) {
        // avoiding dynamic allocation
        nodes_.push_back({left, right, value});
        return &nodes_.back();
    }
    Node* ChangeOnSegment(int index, Node* node,
        int left_bord = -1e9, int right_bord = 1e9) {
        if (!node) {
            node = CreateNode();
        }
        if (left_bord == right_bord) {
            return CreateNode(node->value + 1);
        }
        int middle = left_bord + (right_bord - left_bord) / 2;
        Node* new_node = CreateNode(0, node->left, node->right);
        if (index <= middle) {
            new_node->left = ChangeOnSegment(index, node->left, left_bord, middle);
        } else {
            new_node->right = ChangeOnSegment(index, node->right, middle + 1, right_bord);
        }
        new_node->value = new_node->left->value + new_node->right->value;
        return new_node;
    }
    int Query(Node* first, Node* second, int k, int left_bord = -1e9, int right_bord = 1e9) {
        if (left_bord == right_bord) {
            return left_bord;
        }
        int middle = left_bord + (right_bord - left_bord) / 2;
        int num_of_lows = second->left->value - first->left->value;
        if (k <= num_of_lows) {
            return Query(first->left, second->left, k, left_bord, middle);
        }
        return Query(first->right, second->right, k - num_of_lows, middle + 1, right_bord);
    }
    void Insert(int i, int elem) {
        roots_[i] = ChangeOnSegment(elem, roots_[i - 1]);
    }
    int KthStatistics(int left, int right, int k) {
        return Query(roots_[left - 1], roots_[right], k);
    }
private:
    std::vector<Node*> roots_;
    std::vector<Node> nodes_;
};


int main(){
    int n, m;
    scanf("%d%d", &n, &m);
    PersistentSegmentTree tree(n);
    for (int i = 1;i <= n; ++i){
        int x;
        scanf("%d", &x);
        tree.Insert(i, x);
    }
    for (int i = 0; i < m; ++i){
        int l, r, k;
        scanf("%d%d%d", &l, &r, &k);
        printf("%d\n", tree.KthStatistics(l, r, k));
    }
    return 0;
}