#include <algorithm>
#include <cassert>
#include <iostream>
#include <iterator>
#include <vector>
#include <queue>
#include <string.h>

struct Edge {
    int src;
    int dest;
    int cap;
    int flow;
};

class Graph {
public:
    explicit Graph(int vertices_num) {
        source_ = 0;
        sink_ = vertices_num + 1;
        vertices_num_ = vertices_num;
    }

    void AddEdge(int src, int dest, int capacity) {
        adj_lists_[src].emplace_back(curr_num_);
        edges_[curr_num_] = {src, dest, capacity, 0};
        ++curr_num_;
        adj_lists_[dest].emplace_back(curr_num_);
        edges_[curr_num_] = {dest, src, 0, 0};
        ++curr_num_;
    }

    void BFS() {
        memset(dist_, -1, sizeof(dist_));
        memset(q_, 0, sizeof(q_));
        int last = 0, front = 0;
        q_[last++] = source_;
        dist_[source_] = 0;
        while (front < last && dist_[sink_] == -1) {
            int curr_vertex = q_[front++];
            for (int id : adj_lists_[curr_vertex]) {
                if (dist_[edges_[id].dest] == -1 && edges_[id].cap - edges_[id].flow > 0) {
                    dist_[edges_[id].dest] = dist_[curr_vertex] + 1;
                    q_[last++] = edges_[id].dest;
                }
            }
        }
    }

    void ChangeCapacity(int edge_num, int new_capacity) {
        edges_[edge_num].cap = new_capacity;
    }

    inline int DFS(int start, int flow) {
        if (start == sink_ || flow == 0) {
            return flow;
        }
        while (static_cast<size_t>(pointers_[start]) < adj_lists_[start].size()) {
            int id = adj_lists_[start][pointers_[start]];
            int target = edges_[id].dest;
            if (dist_[target] != dist_[start] + 1) {
                ++pointers_[start];
                continue;
            }
            int pushed = DFS(target, std::min(edges_[id].cap - edges_[id].flow, flow));
            if (pushed > 0) {
                edges_[id].flow += pushed;
                edges_[id ^ 1].flow -= pushed;
                return pushed;
            }
            ++pointers_[start];
        }
        return 0;
    }

    inline int Dinic() {
        for (auto& edge : edges_) {
            edge.flow = 0;
        }
        int answer = 0;
        do {
            memset(pointers_, 0, sizeof(pointers_));
            BFS();
            if (dist_[sink_] == -1) {
                break;
            }
            while (int pushed = DFS(source_, inf_)) {
                answer += pushed;
            }
        } while (dist_[sink_] != -1);
        return answer;
    }

private:
    int curr_num_ = 0, vertices_num_;
    int pointers_[120];
    int dist_[120];
    int q_[120];
    Edge edges_[4000];
    int pointers_to_vertices_[120];
    std::vector<int> adj_lists_[120];
    int source_, sink_;
    const int inf_ = 100000000;
    std::queue<int> order_;
};

Graph BuildGraph(const std::vector<int>& masks, const std::vector<int>& capacities) {
    int people_num = static_cast<int>(masks.size());
    int total_ships = static_cast<int>(capacities.size());
    Graph graph(total_ships + people_num);
    for (int i = 0; i < total_ships; ++i) {
        graph.AddEdge(1 + people_num + i, total_ships + people_num + 1, capacities[i]);
    }
    for (int i = 0; i < people_num; ++i) {
        graph.AddEdge(0, i + 1, 1);
        int current_mask = masks[i], ship_num = 0;
        while (current_mask) {
            if (current_mask & 1) {
                graph.AddEdge(i + 1, 1 + people_num + ship_num, 1);
            }
            current_mask >>= 1;
            ++ship_num;
        }
    }
    return graph;
}

void ChangeGraph(Graph& graph, const std::vector<int>& capacities, int mask) {
    unsigned int total_ships = static_cast<unsigned int>(capacities.size());
    for (unsigned int i = 0; i < total_ships; ++i) {
        if (mask & 1) {
            graph.ChangeCapacity(i << 1, capacities[i]);
        } else {
            graph.ChangeCapacity(i << 1, 0);
        }
        mask >>= 1;
    }
}

struct Input {
    std::vector<int> capacities, masks;
};

inline int NumOfShips(int mask) {
    int answer = 0;
    while (mask) {
        answer += mask & 1;
        mask >>= 1;
    }
    return answer;
}

template<class Predicate>
int BinSearch(int begin, int end, Predicate predicate) {
    // finds least iterator from [begin, end) such that predicate(iterator) = true
    // if there is no such iterator, returns end
    int left = begin, right = end;
    while (right > left) {
        int middle = left + (right - left) / 2;
        if (predicate(middle)) {
            right = middle;
        } else {
            left = middle + 1;
        }
    }
    if (left == end) {
        return -1;
    }
    return left;
}

int FindMinimumCompany(const Input& input) {
    int total_ships = static_cast<int>(input.capacities.size());
    int people_num = static_cast<int>(input.masks.size());
    Graph graph = BuildGraph(input.masks, input.capacities);
    return BinSearch(0, total_ships + 1, [&](int count) {
        if (count == 0) {
            return false;
        }
        unsigned int mask = (1 << count) - 1;
        while (mask <= static_cast<unsigned int>(((1 << count) - 1)
            << (total_ships - count))) {
            ChangeGraph(graph, input.capacities, mask);
            if (graph.Dinic() == people_num) {
                return true;
            }
            unsigned int t_ = (mask | (mask - 1)) + 1;
            mask = t_ | ((((t_ & -t_) / (mask & -mask)) >> 1) - 1);
            /* int t_ = mask | (mask - 1);
            mask = (t_ + 1) | (((~t_ & -~t_) - 1) >> (__builtin_ctz(mask) + 1)); */
        }
        return false;
    });
}

Input GetInput(std::istream& in = std::cin) {
    int total_ships, people_num;
    in >> total_ships >> people_num;
    std::vector<int> capacities(total_ships);
    for (int& capacity : capacities) {
        in >> capacity;
    }
    std::vector<int> masks(people_num);
    for (int i = 0; i < people_num; ++i) {
        int ships_num_for_person;
        in >> ships_num_for_person;
        for (int j = 0; j < ships_num_for_person; ++j) {
            int current_num;
            in >> current_num;
            masks[i] |= (1 << (current_num - 1));
        }
    }
    return {capacities, masks};
}

int main() {
    std::ios_base::sync_with_stdio(false);
    auto input = GetInput();
    std::cout << FindMinimumCompany(input) << "\n";
    return 0;
}
