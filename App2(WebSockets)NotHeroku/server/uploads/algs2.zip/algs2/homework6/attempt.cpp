#include <algorithm>
#include <iostream>
#include <iterator>
#include <vector>
#include <random>

struct Node {
    int left, right, value;
    explicit Node(int left_, int right_, int value_)
        : left(left_), right(right_), value(value_) {}
};

class PersistentSegmentTree {
public:
    PersistentSegmentTree() {
        roots_.push_back(AddNode(0, terminal_, terminal_));
    }
    int AddNode(int value, int left, int right) {
        container_.emplace_back(Node(left, right, value));
        return container_.size() - 1;
    };
    int GetValue(int node) {
        if (node == terminal_) {
            return 0;
        }
        return container_[node].value;
    }
    int GetLeft(int node) {
        if (node == terminal_) {
            return terminal_;
        }
        return container_[node].left;
    }
    int GetRight(int node) {
        if (node == terminal_) {
            return terminal_;
        }
        return container_[node].right;
    }
    int ChangeOnSegment(int node, int index, int left_bord, int right_bord) {
        if (node == terminal_) {
            if (left_bord == right_bord) {
                int value = AddNode(1, terminal_, terminal_);
                return value;
            }
            node = AddNode(0, terminal_, terminal_);
        }
        if (left_bord == right_bord) {
            return AddNode(container_[node].value + 1, terminal_, terminal_);
        }
        int new_node = AddNode(0, container_[node].left, container_[node].right);
        int middle = left_bord + (right_bord - left_bord) / 2;
        if (index <= middle) {
            int value = ChangeOnSegment(container_[node].left, index,
                left_bord, middle);
            container_[new_node].left = value;
        } else {
            int value = ChangeOnSegment(container_[node].right, index,
                middle + 1, right_bord);
            container_[new_node].right = value;
        }
        container_[new_node].value = GetValue(container_[new_node].left)
            + GetValue(container_[new_node].right);
        return new_node;
    }
    void Change(int index) {
        roots_.push_back(ChangeOnSegment(roots_.back(), index, left_bound_, right_bound_));
    }
    int RecursiveQuery(int first, int second, int order, int left_bord, int right_bord) {
        if (left_bord == right_bord) {
            return left_bord;
        }
        int middle = left_bord + (right_bord - left_bord) / 2;
        int number_of_lows = GetValue(GetLeft(second)) - GetValue(GetLeft(first));
        if (order <= number_of_lows) {
            return RecursiveQuery(GetLeft(first), GetLeft(second),
                order, left_bord, middle);
        }
        return RecursiveQuery(GetRight(first), GetRight(second), order - number_of_lows,
            middle + 1, right_bord);
    }
    int KthStatistics(int left, int right, int order) {
        return RecursiveQuery(roots_[left - 1], roots_[right], order, left_bound_, right_bound_);
    }
    void BuildForArray(const std::vector<int>& arr) {
        for (const int elem : arr) {
            Change(elem);
        }
    }

private:
    std::vector<int> roots_;
    std::vector<Node> container_;
    const int terminal_ = -1, left_bound_ = -1e9, right_bound_ = 1e9;
};

struct Query {
    int left, right, order;
    explicit Query(int left_, int right_, int order_)
        : left(left_), right(right_), order(order_) {} 
};

struct Input {
    std::vector<int> arr;
    std::vector<Query> queries;
};

std::vector<int> GenerateArray(int numbers_count, int a_, int64_t l_, int64_t m_) {
    std::vector<int> res(numbers_count);
    res.front() = a_;
    for (int i = 1; i < numbers_count; ++i) {
        int64_t value = (static_cast<int64_t>(res[i - 1]) * l_ + m_) % static_cast<int64_t>(1e9);
        if (value < 0) {
            value += static_cast<int64_t>(1e9);
        }
        res[i] = value;
    }
    return res;
}

std::vector<Query> GenerateQueries(int64_t numbers_count, int groups_num,
    std::istream& in = std::cin) {
    std::vector<Query> res;
    for (int it = 0; it < groups_num; ++it) {
        int queries, x_first, y_first, k_first;
        int64_t l_x, m_x, l_y, m_y, l_k, m_k;
        in >> queries >> x_first >> l_x >> m_x >> y_first >> l_y >> m_y >> k_first >> l_k >> m_k;
        res.emplace_back(Query(std::min(x_first, y_first), std::max(x_first, y_first), k_first));
        for (int jt = 1; jt < queries; ++jt) {
            int64_t module_x = (static_cast<int64_t>(static_cast<int64_t>(res.back().left) - 1)
                * l_x + m_x) % numbers_count;
            if (module_x < 0) {
                module_x += numbers_count;
            }
            int x_j = module_x + 1;
            int64_t module_y = (static_cast<int64_t>(static_cast<int64_t>(res.back().right) - 1)
                * l_y + m_y) % numbers_count;
            if (module_y < 0) {
                module_y += numbers_count;
            }
            int y_j = module_y + 1;
            int64_t module_k = (static_cast<int64_t>(static_cast<int64_t>(res.back().order) - 1)
                * l_k + m_k) % static_cast<int64_t>(std::max(x_j, y_j) - std::min(x_j, y_j) + 1);
            if (module_k < 0) {
                module_k += static_cast<int64_t>(std::max(x_j, y_j) - std::min(x_j, y_j) + 1);
            }
            int k_j = module_k + 1;
            res.emplace_back(Query(std::min(x_j, y_j), std::max(x_j, y_j), k_j));
        }
    }
    return res;
}

Input GetInput(std::istream& in = std::cin) {
    int numbers_count;
    in >> numbers_count;
    int64_t a_, l_, m_;
    in >> a_ >> l_ >> m_;
    auto arr = GenerateArray(numbers_count, a_, l_, m_);
    int groups_num;
    in >> groups_num;
    auto queries = GenerateQueries(numbers_count, groups_num);
    return {arr, queries};
}

int64_t FindSumOfStatistics(const Input& input) {
    PersistentSegmentTree tree;
    tree.BuildForArray(input.arr);
    int64_t answer = 0;
    for (const auto& query : input.queries) {
        answer += tree.KthStatistics(query.left, query.right, query.order);
    }
    return answer;
}

int main() {
    std::ios_base::sync_with_stdio(false);
    auto input = GetInput();
    std::cout << FindSumOfStatistics(input) << "\n";
    return 0;
}
