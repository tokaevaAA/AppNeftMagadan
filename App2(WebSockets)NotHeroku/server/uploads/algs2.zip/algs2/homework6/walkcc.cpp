#include <algorithm>
#include <cassert>
#include <iostream>
#include <iterator>
#include <vector>
#include <queue>
#include <string.h>

const int MAXN = 120; // число вершин
const int INF = 1000000000;

struct edge {
	int a, b, cap, flow;
};
 
int n, s, t, d[MAXN], ptr[MAXN], q[MAXN];
std::vector<edge> e;
std::vector<int> g[MAXN];
 
void add_edge (int a, int b, int cap) {
	edge e1 = { a, b, cap, 0 };
	edge e2 = { b, a, 0, 0 };
	g[a].push_back ((int) e.size());
	e.push_back (e1);
	g[b].push_back ((int) e.size());
	e.push_back (e2);
}

void ChangeCapacity(int id, int value) {
    e[id].cap = value;
}

bool bfs() {
	int qh=0, qt=0;
	q[qt++] = s;
	memset (d, -1, n * sizeof d[0]);
	d[s] = 0;
	while (qh < qt && d[t] == -1) {
		int v = q[qh++];
		for (size_t i=0; i<g[v].size(); ++i) {
			int id = g[v][i],
				to = e[id].b;
			if (d[to] == -1 && e[id].flow < e[id].cap) {
				q[qt++] = to;
				d[to] = d[v] + 1;
			}
		}
	}
	return d[t] != -1;
}
 
int dfs (int v, int flow) {
	if (!flow)  return 0;
	if (v == t)  return flow;
	for (; ptr[v]<(int)g[v].size(); ++ptr[v]) {
		int id = g[v][ptr[v]],
			to = e[id].b;
		if (d[to] != d[v] + 1)  continue;
		int pushed = dfs (to, std::min (flow, e[id].cap - e[id].flow));
		if (pushed) {
			e[id].flow += pushed;
			e[id^1].flow -= pushed;
			return pushed;
		}
	}
	return 0;
}

int dinic() {
	int flow = 0;
    for (auto& edge : e) {
        edge.flow = 0;
    }
	for (;;) {
		if (!bfs())  break;
		memset (ptr, 0, n * sizeof ptr[0]);
		while (int pushed = dfs (s, INF))
			flow += pushed;
	}
	return flow;
}

void ChangeGraph(const std::vector<int>& capacities, int mask) {
    int total_ships = static_cast<int>(capacities.size());
    for (int i = 0; i < total_ships; ++i) {
        if (mask & 1) {
            ChangeCapacity(i << 1, capacities[i]);
        } else {
            ChangeCapacity(i << 1, 0);
        }
        mask >>= 1;
    }
}

struct Input {
    std::vector<int> capacities, masks;
};

int NumOfShips(int mask) {
    int answer = 0;
    while (mask) {
        answer += mask & 1;
        mask >>= 1;
    }
    return answer;
}

template<class Predicate>
int BinSearch(int begin, int end, Predicate predicate) {
    // finds least iterator from [begin, end) such that predicate(iterator) = true
    // if there is no such iterator, returns end
    int left = begin, right = end;
    while (right > left) {
        int middle = left + (right - left) / 2;
        if (predicate(middle)) {
            right = middle;
        } else {
            left = middle + 1;
        }
    }
    if (left == end) {
        return -1;
    }
    return left;
}

void BuildGraph(const std::vector<int>& masks, const std::vector<int>& capacities) {
    int people_num = static_cast<int>(masks.size());
    int total_ships = static_cast<int>(capacities.size());
    s = 0;
    t = people_num + total_ships + 1;
    n = people_num + total_ships + 2;
    for (int i = 0; i < total_ships; ++i) {
        add_edge(1 + people_num + i, total_ships + people_num + 1, capacities[i]);
    }
    for (int i = 0; i < people_num; ++i) {
        add_edge(0, i + 1, 1);
        int current_mask = masks[i], ship_num = 0;
        while (current_mask) {
            if (current_mask & 1) {
                add_edge(i + 1, 1 + people_num + ship_num, 1);
            }
            current_mask >>= 1;
            ++ship_num;
        }
    }
}

int FindMinimumCompany(const Input& input) {
    int total_ships = static_cast<int>(input.capacities.size());
    int people_num = static_cast<int>(input.masks.size());
    BuildGraph(input.masks, input.capacities);
    return BinSearch(0, total_ships + 1, [&](int count) {
        if (count == 0) {
            return false;
        }
        unsigned int mask = (1 << count) - 1;
        while (mask <= (((1 << count) - 1) << (total_ships - count))) {
            ChangeGraph(input.capacities, mask);
            if (dinic() == people_num) {
                return true;
            }
            unsigned int t_ = (mask | (mask - 1)) + 1;
            mask = t_ | ((((t_ & -t_) / (mask & -mask)) >> 1) - 1);
            /* int t_ = mask | (mask - 1);
            mask = (t_ + 1) | (((~t_ & -~t_) - 1) >> (__builtin_ctz(mask) + 1)); */
            
        }
        return false;
    });
}

Input GetInput(std::istream& in = std::cin) {
    int total_ships, people_num;
    in >> total_ships >> people_num;
    std::vector<int> capacities(total_ships);
    for (int& capacity : capacities) {
        in >> capacity;
    }
    std::vector<int> masks(people_num);
    for (int i = 0; i < people_num; ++i) {
        int ships_num_for_person;
        in >> ships_num_for_person;
        for (int j = 0; j < ships_num_for_person; ++j) {
            int current_num;
            in >> current_num;
            masks[i] |= (1 << (current_num - 1));
        }
    }
    return {capacities, masks};
}

int main() {
    std::ios_base::sync_with_stdio(false);
    auto input = GetInput();
    std::cout << FindMinimumCompany(input) << "\n";
    return 0;
}
