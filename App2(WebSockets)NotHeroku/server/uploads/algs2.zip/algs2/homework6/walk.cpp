#include <algorithm>
#include <cassert>
#include <iostream>
#include <iterator>
#include <vector>
#include <queue>

struct Edge {
    int src;
    int dest;
    int cap;
    int flow;
};

class Graph {
public:
    explicit Graph(int vertices_num) {
        adj_lists_.resize(vertices_num + 2);
        source_ = 0;
        sink_ = vertices_num + 1;
    }

    void AddEdge(int src, int dest, int capacity) {
        adj_lists_[src].push_back(edges_.size());
        edges_.push_back({src, dest, capacity, 0});
        adj_lists_[dest].push_back(edges_.size());
        edges_.push_back({dest, src, 0, 0});
    }

    std::vector<int> BFS() {
        std::vector<int> dist(adj_lists_.size(), -1);
        std::queue<int> order({source_});
        dist[source_] = 0;
        while (!order.empty()) {
            int curr_vertex = order.front();
            order.pop();
            for (int id : adj_lists_[curr_vertex]) {
                if (dist[edges_[id].dest] == -1 && edges_[id].cap - edges_[id].flow > 0) {
                    dist[edges_[id].dest] = dist[curr_vertex] + 1;
                    order.push(edges_[id].dest);
                }
            }
        }
        return dist;
    }

    void ChangeCapacity(int edge_num, int new_capacity) {
        edges_[edge_num].cap = new_capacity;
    }

    int DFS(std::vector<int>& pointers, const std::vector<int>& dist,
        int start, int flow) {
        if (start == sink_ || flow == 0) {
            return flow;
        }
        while (static_cast<size_t>(pointers[start]) < adj_lists_[start].size()) {
            int id = adj_lists_[start][pointers[start]];
            int target = edges_[id].dest;
            if (dist[target] != dist[start] + 1) {
                ++pointers[start];
                continue;
            }
            int pushed = DFS(pointers, dist, target,
                std::min(edges_[id].cap - edges_[id].flow, flow));
            if (pushed > 0) {
                edges_[id].flow += pushed;
                edges_[id ^ 1].flow -= pushed;
                return pushed;
            }
            ++pointers[start];
        }
        return 0;
    }

    int Dinic() {
        for (auto& edge : edges_) {
            edge.flow = 0;
        }
        int answer = 0;
        do {
            pointers_.assign(adj_lists_.size(), 0);
            dist_ = BFS();
            while (int pushed = DFS(pointers_, dist_, source_, inf_)) {
                answer += pushed;
            }
        } while (dist_[sink_] != -1);
        return answer;
    }

private:
    std::vector<int> pointers_, dist_;
    std::vector<Edge> edges_;
    std::vector<std::vector<int>> adj_lists_;
    int source_, sink_;
    const int inf_ = 100000000;
};

Graph BuildGraph(const std::vector<int>& masks, const std::vector<int>& capacities) {
    int people_num = static_cast<int>(masks.size());
    int total_ships = static_cast<int>(capacities.size());
    Graph graph(total_ships + people_num);
    for (int i = 0; i < total_ships; ++i) {
        graph.AddEdge(1 + people_num + i, total_ships + people_num + 1, capacities[i]);
    }
    for (int i = 0; i < people_num; ++i) {
        graph.AddEdge(0, i + 1, 1);
        int current_mask = masks[i], ship_num = 0;
        while (current_mask) {
            if (current_mask & 1) {
                graph.AddEdge(i + 1, 1 + people_num + ship_num, 1);
            }
            current_mask >>= 1;
            ++ship_num;
        }
    }
    return graph;
}

void ChangeGraph(Graph& graph, const std::vector<int>& capacities, int mask) {
    int total_ships = static_cast<int>(capacities.size());
    for (int i = 0; i < total_ships; ++i) {
        if (mask & 1) {
            graph.ChangeCapacity(2 * i, capacities[i]);
        } else {
            graph.ChangeCapacity(2 * i, 0);
        }
        mask >>= 1;
    }
}

struct Input {
    std::vector<int> capacities, masks;
};

int NumOfShips(int mask) {
    int answer = 0;
    while (mask) {
        answer += mask & 1;
        mask >>= 1;
    }
    return answer;
}

template<class Predicate>
int BinSearch(int begin, int end, Predicate predicate) {
    // finds least iterator from [begin, end) such that predicate(iterator) = true
    // if there is no such iterator, returns end
    int left = begin, right = end;
    while (right > left) {
        int middle = left + (right - left) / 2;
        if (predicate(middle)) {
            right = middle;
        } else {
            left = middle + 1;
        }
    }
    if (left == end) {
        return -1;
    }
    return left;
}

int FindMinimumCompany(const Input& input) {
    int total_ships = static_cast<int>(input.capacities.size());
    int people_num = static_cast<int>(input.masks.size());
    Graph graph = BuildGraph(input.masks, input.capacities);
    return BinSearch(0, total_ships + 1, [&](int count) {
        if (count == 0) {
            return false;
        }
        int mask = (1 << count) - 1;
        while (mask <= (((1 << count) - 1) << (total_ships - count))) {
            ChangeGraph(graph, input.capacities, mask);
            if (graph.Dinic() == people_num) {
                return true;
            }
            int t_ = (mask | (mask - 1)) + 1;
            mask = t_ | ((((t_ & -t_) / (mask & -mask)) >> 1) - 1);
            /* int t_ = mask | (mask - 1);
            mask = (t_ + 1) | (((~t_ & -~t_) - 1) >> (__builtin_ctz(mask) + 1)); */
            
        }
        return false;
    });
}

Input GetInput(std::istream& in = std::cin) {
    int total_ships, people_num;
    in >> total_ships >> people_num;
    std::vector<int> capacities(total_ships);
    for (int& capacity : capacities) {
        in >> capacity;
    }
    std::vector<int> masks(people_num);
    for (int i = 0; i < people_num; ++i) {
        int ships_num_for_person;
        in >> ships_num_for_person;
        for (int j = 0; j < ships_num_for_person; ++j) {
            int current_num;
            in >> current_num;
            masks[i] |= (1 << (current_num - 1));
        }
    }
    return {capacities, masks};
}

int main() {
    std::ios_base::sync_with_stdio(false);
    auto input = GetInput();
    std::cout << FindMinimumCompany(input) << "\n";
    return 0;
}
