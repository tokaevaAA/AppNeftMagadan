#include <algorithm>
#include <iostream>
#include <iterator>
#include <memory>
#include <vector>

struct Node {
    int left, right, value;
    Node(int left_, int right_, int value_)
        : left(left_), right(right_), value(value_) {}
};

class PersistentSegmentTree {
public:
    PersistentSegmentTree() {
        roots_.push_back(AddNode(0, terminal_, terminal_));
    }
    int AddNode(int value, int left, int right) {
        container_.emplace_back(Node(left, right, value));
        return container_.size() - 1;
    };
    int GetValue(int node) {
        if (node == terminal_) {
            return 0;
        }
        return container_[node].value;
    }
    int GetLeft(int node) {
        if (node == terminal_) {
            return terminal_;
        }
        return container_[node].left;
    }
    int GetRight(int node) {
        if (node == terminal_) {
            return terminal_;
        }
        return container_[node].right;
    }
    int ChangeOnSegment(int node, int value, int index, int left_bord, int right_bord) {
        if (node == terminal_) {
            if (left_bord == right_bord) {
                int value = AddNode(value, terminal_, terminal_);
                return value;
            }
            node = AddNode(0, terminal_, terminal_);
        }
        if (left_bord == right_bord) {
            return AddNode(value, terminal_, terminal_);
        }
        int new_node = AddNode(0, container_[node].left, container_[node].right);
        int middle = left_bord + (right_bord - left_bord) / 2;
        if (index <= middle) {
            int value = ChangeOnSegment(container_[node].left, value, index,
                left_bord, middle);
            container_[new_node].left = value;
        } else {
            int value = ChangeOnSegment(container_[node].right, value, index,
                middle + 1, right_bord);
            container_[new_node].right = value;
        }
        container_[new_node].value = GetValue(container_[new_node].left)
            + GetValue(container_[new_node].right);
        return new_node;
    }
    void Change(int index, int value) {
        roots_.push_back(ChangeOnSegment(roots_.back(), value, index, left_bound_, right_bound_));
    }
    int Sum(int node, int left, int right, int left_bord, int right_bord) {
        if (node == terminal_ || left > right) {
            return 0;
        }
        if (left == left_bord && right == right_bord) {
            return container_[node].value;
        }
        int middle = left_bord + (right_bord - left_bord) / 2;
        return Sum(container_[node].left, left, std::min(middle, right), left_bord, middle)
            + Sum(container_[node].right, std::max(middle + 1, left), right, middle + 1,
            right_bord);
    }
    int SumFromVersion(int version, int left, int right) {
        return Sum(roots_[version], left, right, left_bound_, right_bound_);
    }
    int ElemAtIndex(int index, int version) {
        return Sum(roots_[version], index, index, left_bound_, right_bound_);
    }
private:
    std::vector<int> roots_;
    std::vector<Node> container_;
    const int terminal_ = -1, left_bound_ = -1e9, right_bound_ = 1e9;
};

class PersistentDSU {
public:
void MakeSet(int vertex, int version) {
    AssignParentToVertex(vertex, vertex, version);
    AssignRankToVertex(vertex, 0, version);
}
int FindSet(int vertex, int version) {
    int parent = GetParent(vertex, version);
    if (vertex == parent) {
        return vertex;
    }
    return FindSet(parent, version);
}
void UnionSets(int vertex_first, int vertex_second, int version) {
    vertex_first = FindSet(vertex_first, version);
    vertex_second = FindSet(vertex_second, version);
    if (vertex_first != vertex_second) {
        int rank_first = GetRank(vertex_first, version);
        int rank_second = GetRank(vertex_second, version);
        if (rank_first < rank_second) {
            AssignParentToVertex(vertex_first, vertex_second, version);
            if (rank_first == rank_second) {
                AssignRankToVertex(vertex_first, rank_first + 1, version);
            }
        } else {
            AssignParentToVertex(vertex_second, vertex_first, version);
            if (rank_first == rank_second) {
                AssignRankToVertex(vertex_second, rank_second + 1, version);
            }
        }
    }
}
int GetParent(int vertex, int version) {

}
int GetRank(int vertex, int version) {

}
void AssignParentToVertex(int vertex, int parent, int version) {

}
void AssignRankToVertex(int vertex, int rank, int version) {

}
private:
    PersistentSegmentTree parent_, rank_;
};
