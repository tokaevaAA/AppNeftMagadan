#include <algorithm>
#include <iterator>
#include <iostream>
#include <vector>

void PrintNumber(int num) {
    std::vector<bool> mask;
    int current_num = num;
    while (current_num) {
        mask.push_back(current_num & 1);
        current_num >>= 1;
    }
    //std::reverse(mask.begin(), mask.end());
    std::copy(mask.begin(), mask.end(), std::ostream_iterator<int>(std::cout, ""));
    std::cout << std::endl;
}

void Ex() {
    for (int i = 0; i < 10000; ++i);
}

void Loop(unsigned int v, int k) {
    unsigned int curr = v;
    // PrintNumber(curr);
    while (curr < (v << (16 - k))) {
        unsigned int t = (curr | (curr - 1)) + 1;
        unsigned int w = t | ((((t & -t) / (curr & -curr)) >> 1) - 1);
        // PrintNumber(w);
        curr = w;
        Ex();
    }
}

void BigLoop() {
    for (unsigned int k = 0; k < 17; ++k) {
        Loop((1 << k) - 1, k);
    }
}

void Looop() {
    for (unsigned int mask = 0; mask < (1 << 16); ++mask) {
        Ex();
    }
}

int main() {
    BigLoop();
    return 0;
}