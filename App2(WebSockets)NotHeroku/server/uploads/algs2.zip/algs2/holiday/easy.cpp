#include <algorithm>
#include <iostream>
#include <string>

int main() {
    std::ios_base::sync_with_stdio(false);
    std::string text;
    std::getline(std::cin, text);
    std::cout << (int)text[0] << " ";
    if (text.size() > 1) std::cout << (int)text[1];
    std::reverse(text.begin(), text.end());
    std::cout << text << std::endl;
    return 0;
}