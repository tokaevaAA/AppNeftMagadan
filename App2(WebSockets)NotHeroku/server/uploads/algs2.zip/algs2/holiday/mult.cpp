#include <iostream>

const int n = 2000;

int matrix[n * n];

int res[n * n];

void Fill(int i, int j) {
    if (i == 0 || j == 0) {
        matrix[i + n * j] = 1;
    } else {
        matrix[i + n * j] = (2 * matrix[i - 1 + n * j] + 3 * matrix[i + (j - 1) * n]) % 1000003;
    }
}

void Mult() {
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            int elem = 0;
            for (int k = 0; k < n; ++k) {
                elem += matrix[i + k * n] * matrix[k + j * n];
            }
            res[i + j * n] = elem;
        }
    }
}

void Write() {
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            if (res[i + n * j] % 47 == 0) {
                std::cout << i + 1 << " " << j + 1 << "\n";
            }
        }
    }
}

int main() {
    std::ios_base::sync_with_stdio(false);
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) Fill(i, j);
    }
    for (int i = 0; i < n * n; ++i) matrix[i] = matrix[i] % 47;
    Mult();
    Write();
    return 0;
}
