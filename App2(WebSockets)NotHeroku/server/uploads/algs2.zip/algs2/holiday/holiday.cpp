 # include<iostream> 
 using 
 namespace std ;  
 int                    
 main ( ) 
    {  ; int  a ,b ,c ,d ,e ,f; 
        cin>>a>>b  ; if (a < 0) cin>>d>>c>>e>>f ;
            cout<<(int64_t)a+(int64_t)b<<"\n" ;
            return  0 ; cin>>a>>b>>c ; } 