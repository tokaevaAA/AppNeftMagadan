#include <algorithm>
#include <iostream>
#include <iterator>
#include <vector>

std::vector<int> ReadVector(std::istream& in = std::cin) {
    size_t size;
    in >> size;
    std::vector<int> result(size);
    for (int& elem : result) {
        in >> elem;
    }
    return result;
}

class Trie { 
public:
    int value;
    int idx;
    Trie* child[2];
    Trie() {
        value = idx = 0;
        child[0] = child[1] = 0;
    } 
};
  
int MaxXOR(Trie* root, int elem) { 
    Trie* temp = root; 
    for (int i = 31; i >= 0; i--) {  
        bool currBit = elem & (1 << i);  
        if (temp->child[1 - currBit]) {
            temp = temp->child[1 - currBit];
        } else {
            temp = temp -> child[currBit];
        }
    }
    return temp->idx; 
} 

void Insert(Trie* root, int elem, int idx) { 
    Trie* temp = root; 
    for (int i = 31; i >= 0; --i) { 
        bool currBit = elem & (1 << i); 
        if (!temp -> child[currBit]) {
            temp -> child[currBit] = new Trie;
        }       
        temp = temp -> child[currBit]; 
    }
    temp->value = elem; 
    temp->idx = idx;
} 

void DeleteTrie(Trie* root) {
    if (root->child[0]) {
        DeleteTrie(root->child[0]);
    }
    if (root->child[1]) {
        DeleteTrie(root->child[1]);
    }
    delete root;
}

int main() {
    std::ios_base::sync_with_stdio(false);
    auto first = ReadVector();
    auto second = ReadVector();
    Trie* root = new Trie;
    for (int i = 0; i < static_cast<int>(first.size()); ++i) {
        Insert(root, first[i], i);
    }
    std::vector<int> result;
    for (auto elem : second) {
        int res = MaxXOR(root, elem);
        result.push_back(first[res]);
    }
    std::copy(result.begin(), result.end(), std::ostream_iterator<int>(std::cout, " "));
    std::cout << "\n";
    DeleteTrie(root);
    return 0;
}
