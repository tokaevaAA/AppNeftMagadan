#include <iostream>
#include <vector>
#include <cstdlib>

  using std::cin;
  using std::cout;
  using std::vector;
  using std::endl;

struct footballer {
  int number;
  int skill;
  };

void Input (vector <footballer>& BARCA) {
    int team;
    cin >> team;
    for ( int ii = 0; ii < team; ++ii ) {
        int aa;
        cin >> aa;
        footballer Messi;
        Messi.number = ii;
        Messi.skill = aa;
        BARCA.push_back(Messi);
    }
}

void Sorted (vector <footballer>& start, int aa, int bb) {
  int nn = bb - aa + 1;
  if ( nn > 2 ) {
  int cc = rand() % nn;
  footballer base_element = start[ cc + aa ];
  start[ cc + aa ] = start[ bb ];
  start[ bb ] = base_element;
  int ii = aa;
  int jj = bb - 1;
  while ( jj > ii ) {
    if ( start[ ii ].skill >= base_element.skill && start[ jj ].skill < base_element.skill ) {
        footballer kk = start[ ii ];
        start[ ii ] = start[ jj ];
        start[ jj ] = kk;
        ii++;
        jj--;
    }
    if ( start[ ii ].skill >= base_element.skill && start[ jj ].skill >= base_element.skill ) {
        jj--;
    }
    if ( start[ ii ].skill < base_element.skill && start[ jj ].skill < base_element.skill ) {
        ii++;
    }
    if ( start[ ii ].skill < base_element.skill && start[ jj ].skill >= base_element.skill ) {
        ii++;
        jj--;
    }
  }
  if ( ii == aa && jj == aa ) {
        start[ bb ] = start[ aa ];
  start[ aa ] = base_element;
  ++ii; }
  int a_1a = aa;
  int b_1b = bb;
  if ( start[ ii ].skill >= base_element.skill ) {
        a_1a = ii;
        bb = ii - 1; } else {
        a_1a = ii + 1;
        bb = ii; }
  if ( bb > 0 ) { Sorted(start, aa, bb); }
  Sorted(start, a_1a, b_1b);
  } else { if ( nn == 2 ) {
      if ( start[ aa ].skill > start[ bb ].skill ) {
            footballer yy = start[ aa ];
      start[ aa ] = start[ bb ];
      start[ bb ] = yy; }
      }
  }
}

void Sorted_2 (vector < int >& start, int aa, int bb) {
  int nn = bb - aa + 1;
  if ( nn > 2 ) {
  int cc = rand() % nn;
  int base_element = start[ cc + aa ];
  start[ cc + aa ] = start[ bb ];
  start[ bb ] = base_element;
  int ii = aa;
  int jj = bb - 1;
  while ( jj > ii ) {
    if ( start[ ii ] >= base_element && start[ jj ] < base_element ) {
        int kk = start[ ii ];
        start[ ii ] = start[ jj ];
        start[ jj ] = kk;
        ii++;
        jj--;
    }
    if ( start[ ii ] >= base_element && start[ jj ] >= base_element ) {
        jj--;
    }
    if ( start[ ii ] < base_element && start[ jj ] < base_element ) {
        ii++;
    }
    if ( start[ ii ] < base_element && start[ jj ] >= base_element ) {
        ii++;
        jj--;
    }
  }
  if ( ii == aa && jj == aa ) {
        start[ bb ] = start[ aa ];
  start[ aa ] = base_element;
  ++ii; }
  int a_1a = aa;
  int b_1b = bb;
  if ( start[ ii ] >= base_element ) {
        a_1a = ii;
  bb = ii - 1; } else {
        a_1a = ii + 1;
        bb = ii; }
  if ( bb > 0 ) { Sorted_2(start, aa, bb); }
  Sorted_2(start, a_1a, b_1b);
  } else { if ( nn == 2 ) {
      if ( start[ aa ] > start[ bb ] ) {
            int yy = start[ aa ];
      start[ aa ] = start[ bb ];
      start[ bb ] = yy; }
      }
  }
}

void Best_Team (vector <footballer>& Barca) {
  int aa = 0;
  int bb = Barca.size() - 1;
  Sorted(Barca, aa, bb);
  footballer Best_Player = Barca[ Barca.size() - 1 ];
  long long  Power = Barca[ Barca.size() - 1 ].skill + Barca[ Barca.size() - 2 ].skill;
  long long Power_contin = Barca[ Barca.size() - 1 ].skill + Barca[ Barca.size() - 2 ].skill;
  int KK = Barca.size() - 1;
  int beg = Barca.size() - 2;
  int finish = Barca.size() - 1;
  for ( int ii = Barca.size() - 3; ii > 0; --ii ) {
       if ( Barca[ ii ].skill < Best_Player.skill - Barca[ ii + 1 ].skill ) {
            if ( Power_contin > Power ) {
                    Power = Power_contin;
            beg = ii + 1;
            finish = KK; }
            Power_contin -= Best_Player.skill;
            Power_contin += Barca[ ii ].skill;
            --KK;
            Best_Player = Barca[ KK ]; } else {
            Power_contin += Barca[ ii ].skill; }
  }
  if ( Power_contin > Power ) {
    Power = Power_contin;
    beg = 0;
    finish = KK; }
  cout << Power << endl;
  vector < int > ss;
  for ( int index = beg; index < finish + 1; ++index ) {
       ss.push_back(Barca[ index ].number) ; }
       int qq = 0;
       int pp = ss.size() - 1;
       Sorted_2(ss, qq, pp);
       for ( int index = 0; index < ss.size(); ++index ) {
       cout << ss[ index ] + 1 << ' '; }
}



int main() {
    vector <footballer> Barca;
    Input(Barca);
    if ( Barca.size() > 1 ) {
    Best_Team(Barca); } else {
    cout << Barca[  0 ].skill << endl;
    cout <<  Barca[ 0 ].number + 1 << endl; }
    return 0;
}
